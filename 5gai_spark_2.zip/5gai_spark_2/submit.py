#!/usr/bin/env python
# -*- coding: utf-8 -*-

from subprocess import call
from datetime import datetime
from datetime import timedelta

# 日志，程序包，mysql驱动，基站数据表结构
log   = "-Dlog4j.configuration='file:/home/iss/Downloads/gsta/5gai_spark_2/src/main/resources/log4j.properties'"
jar   = '/home/iss/Downloads/gsta/5gai_spark_2/target/5gai_spark_2-2.0.jar'
mysql = '/opt/java/repo/mysql/mysql-connector-java/5.1.45/mysql-connector-java-5.1.45.jar'

def submit():
    call([
        '/opt/java/spark/bin/spark-submit',
        '--driver-class-path', mysql,
        '--class', 'com.gsta.GenerateDay',
        '--driver-memory', '4g',
        '--executor-memory', '2g',
        '--executor-cores', '2',
        '--num-executors', '1',
        # '--master', 'yarn',
        # '--deploy-mode', 'client',
        '--queue', 'default',
        '--driver-java-options', log,
        '--conf', 'spark.kryoserializer.buffer.max=1g',
        '--conf', 'spark.driver.maxResultSize=4g',
        '--conf', 'spark.shuffle.io.maxRetries=60',
        '--conf', 'spark.shuffle.memoryFaction=0.7',
        '--conf', 'spark.default.parallelism=200',
        jar
    ])


if __name__ == "__main__":
    fmt = '%Y-%m-%d %H:%M:%S'
    start = datetime.now().strftime(fmt)

    # begin = datetime(2019, 10, 14)
    # end = datetime(2019, 10, 27)
    # while begin <= end:
    #     call(['hadoop', 'fs', '-rm', '-r', '-f', '/WID/WID_DWPRB_DAY/{}'.format(begin.strftime('%Y%m%d'))])
    #     call(['hadoop', 'fs', '-mkdir', '/WID/WID_DWPRB_DAY/{}'.format(begin.strftime('%Y%m%d'))])
    #     call(['rm', '-rf', '/home/iss/Downloads/gsta/5gai_spark_2/{}'.format(begin.strftime('%Y%m%d'))])
    #     begin = begin + timedelta(days=1)

    # with open('/home/iss/Downloads/gsta/5gai_spark_2/gsta.log', 'r') as dataFile:
    #     lines = dataFile.readlines()
    #     for line in lines[1:len(lines)]:
    #         line = line.strip()
    #         data = line[:len(line) - 9]
    #         day = line[-8:]
    #         with open('/home/iss/Downloads/gsta/5gai_spark_2/{}'.format(day), 'a') as targetFile:
    #             targetFile.write(data + '\n')

    begin = datetime(2019, 10, 14)
    end = datetime(2019, 10, 27)
    while begin <= end:
        if begin.day != 21:
            call(['hadoop', 'fs', '-put', '/home/iss/Downloads/gsta/5gai_spark_2/{}'.format(begin.strftime('%Y%m%d')), '/WID/WID_DWPRB_DAY/{}'.format(begin.strftime('%Y%m%d'))])
            call(['hive', '-e', "alter table wid_dwprb_day add IF NOT EXISTS partition(day={day}) location '{day}/'".format(day=begin.strftime('%Y%m%d'))])
        begin = begin + timedelta(days=1)
    # submit()
    # call(['hadoop', 'fs', '-get', hdfs_file + '/part-00000', '/home/iss/Downloads/gsta/5gai_spark_2/result'])

    finish = datetime.now().strftime(fmt)

    print(start)
    print(finish)