# hive

10.17.35.66  
zhanghc  
5gai@66

10.17.35.121:22322  
zhanghc  
5GAI-2019

/usr/java/jdk1.8.0_141-cloudera/bin/java

kinit -kt /home/zhanghc/zhanghc.keytab zhanghc/gsta@GSTA.COM
```

/DATA/PUBLIC/NOCE/AGG/AGG_WIRELESS_KPI_CELL_H/hour=2019041500
/DATA/PUBLIC/NOCE/DIM/DIM_SECTOR/day=20190513
```

```sql
hive -e "use noce;select enodebid,cellid,rrccon_succrate from AGG_WIRELESS_KPI_CELL_H where hour='2019041500' and enodebid='860900' and cellid='2'"
```

# mysql

mysql -h 10.17.35.114 -u 5gai -p 5G_ai_2019
5gai/5G_ai_2019

mysql -h 10.17.35.121 -u EnergySaving5G -p E_s_5g_2019
EnergySaving5G/E_s_5g_2019
energydB
33306