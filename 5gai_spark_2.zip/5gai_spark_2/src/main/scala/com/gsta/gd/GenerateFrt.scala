package com.gsta.gd

import java.sql.{DriverManager, Statement}
import java.util.Calendar

import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.{Encoders, SparkSession}
import org.slf4j.LoggerFactory

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.io.Source

object GenerateFrt extends Util with Serializable {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    val sectorTable = args(0)
    val sectorDate = args(1)

    val date = args(2)
    val dwprbHiveTable = args(3).split(",").head
    val maxactHiveTable = args(3).split(",").last
    val somTable = args(4)
    val host_port = args(5)
    val db = args(6)
    val user = args(7)
    val password = args(8)
    val targetSchema = Source.fromFile(args(9))
    val insertFields = targetSchema.getLines().map(_.trim.split("\\s+")).map(columns => (columns(0), columns(1))).toList
    val targetTable = args(10)
    val pageSize = args(11).toInt

    targetSchema.close()

    val middleStart = date.split(",").head
    val middleEnd = date.split(",").last
    val middleStartCal = Calendar.getInstance()
    val middleEndCal = Calendar.getInstance()
    middleStartCal.setTime(dateFmt.parse(middleStart.split(",").head))
    middleEndCal.setTime(dateFmt.parse(middleEnd.split(",").last))

    /*val monday = Calendar.getInstance()
    val sunday = Calendar.getInstance()
    monday.setTime(dateFmt.parse(yearDate.split(",").head))
    sunday.setTime(dateFmt.parse(yearDate.split(",").last))
    val weekDateMap = ((1, (dateFmt.format(monday.getTime), dateFmt.format(sunday.getTime))) +: 2.to(52).map(i => {
      monday.add(Calendar.DATE, 7)
      sunday.add(Calendar.DATE, 7)
      (i, (dateFmt.format(monday.getTime), dateFmt.format(sunday.getTime)))
    })).toMap

    val weekIndex = weekDateMap.filter(kv => kv._2._1 == middleStart || kv._2._2 == middleEnd).keys.toList.sorted
    val weekIndexHead = weekIndex.head
    val weekIndexTail = weekIndex.last*/

    // mysql
    Class.forName(mysqlDriver)
    val mysqlConnect = DriverManager.getConnection(s"jdbc:mysql://$host_port/$db?user=$user&password=$password&useSSL=false&rewriteBatchedStatements=true")
    val mysqlStmt = mysqlConnect.createStatement()
    mysqlConnect.setAutoCommit(false)

    // val dwprbYearMap = loadYearDataFromMysql(mysqlStmt, yearTable.split(",").head, dwprbFields)
    // val maxactYearMap = loadYearDataFromMysql(mysqlStmt, yearTable.split(",").last, maxactFields)
    // val somMap = loadSomDataFromMysql(mysqlStmt, somTable)
    // val corrMap = loadCorrFromMysql(mysqlStmt, corrTable)
    // val stabilityMap = loadStabilityFromMysql(mysqlStmt, stabilityTable)

    // hive
    val spark = SparkSession.builder().appName("5GAI-generate-frt-data").enableHiveSupport().getOrCreate()

    val somMap = loadSomData(spark, somTable, middleEnd.toInt)
    val dwprbSql = s"select base_statn_id, cell_id, day, day_of_week, dwprbmax, dwprbmean, ${0.to(23).map(hour => s"dwprbH${fmt2Bit(hour)}_fill").mkString(",")}, ${1.to(7).map(i => s"low${i}_dwprb_period").mkString(",")}, trough, peak, near_stable_1st, near_stable_contain_trough from $dwprbHiveTable where day >= $middleStart and day <= $middleEnd order by day"
    val maxactSql = s"select base_statn_id, cell_id, day, day_of_week, maxactmax, zero_actuser_period, less_actuser_period from $maxactHiveTable where day >= $middleStart and day <= $middleEnd order by day"

    val province_id = spark.sql(s"select province_id from $dwprbHiveTable limit 1").collect().map(_.getInt(0)).head
    val dwprbData = spark.sql(dwprbSql).collect().groupBy(row => (row.getInt(0), row.getInt(1)))
    val maxactData = spark.sql(maxactSql).collect().groupBy(row => (row.getInt(0), row.getInt(1)))
    val sectorList = generateDimSectorData(spark, sectorTable, sectorDate.toInt)

    val sqlClause = mutable.ListBuffer[String]()
    sectorList.foreach(kv => {
      val key = kv._1
      val key_string = (kv._1._1.toString, kv._1._2.toString)
      val sectorRow = kv._2
      val is_indoor = sectorRow.getString(5)
      if ( /*maxactYearMap.contains(key) || dwprbYearMap.contains(key) || */ maxactData.contains(key) || dwprbData.contains(key)) {
        val row = generateDimSectorInfo(sectorRow)
        row.prepend(s"$province_id")
        row.append(s"'$middleStart'")
        row.append(s"'$middleEnd'")

        /*if (maxactYearMap.contains(key)) {
          val maxactRecord = maxactYearMap(key)
          val maxactValues = 1.to(52).map(i => {
            val week = if (i < 10) s"0$i" else s"$i"
            maxactRecord(s"maxact_max_w$week").toFloat
          })
          row.append(maxactValues.count(_ == 0).toString)
          row.append(if ("室内" == is_indoor) maxactValues.count(x => 0 <= x && x < 2).toString else maxactValues.count(x => 0 <= x && x < 3).toString)
          row.append(maxactValues.count(x => 60 < x).toString)
        } else {
          16.to(18).foreach(_ => row.append(null))
        }*/
        18.to(20).foreach(_ => row.append(null))

        /*if (dwprbYearMap.contains(key)) {
          val dwprbRecord = dwprbYearMap(key)
          val dwprbValues = 1.to(52).map(i => {
            val week = if (i < 10) s"0$i" else s"$i"
            dwprbRecord(s"dwprb_max_w$week").toFloat
          })

          val peak = dwprbRecord("peak")
          val dwprb_max = dwprbRecord("dwprb_max").toFloat
          val peak_near_stable_1st = dwprbRecord("peak_near_stable_1st")
          val trough = dwprbRecord("trough")
          val trough_max = dwprbRecord("trough_max").toFloat
          val near_stable_contain_trough = dwprbRecord("near_stable_contain_trough")
          val near_stable_contain_trough_max = dwprbRecord("near_stable_contain_trough_max").toFloat
          val peak_near_stable_1st_mean = dwprbRecord("peak_near_stable_1st_mean").toFloat
          val near_stable_1st_max = dwprbRecord("near_stable_1st_max").toFloat
          val near_stable_1st = dwprbRecord("near_stable_1st")
          val rank = dwprbRecord("rank").toInt
          row.append(dwprbValues.count(x => 0 < x && x <= 0.05).toString)
          row.append(dwprbValues.count(x => 0 < x && x <= 0.1).toString)
          row.append(dwprbValues.count(x => 0.6 < x).toString)

          var tideType = -1
          if (peak != null && !peak.isEmpty && peak_near_stable_1st != null
            && trough != null && !trough.isEmpty && near_stable_contain_trough != null && near_stable_1st != null
            && dwprb_max > 0.1
            && peak_near_stable_1st.split(":").last.toInt - peak_near_stable_1st.split(":").head.toInt > 5
            && ((math.abs(trough.split(":").last.toInt - trough.split(":").head.toInt) > 0 && trough_max < 0.15)
            || (math.abs(near_stable_contain_trough.split(":").last.toInt - near_stable_contain_trough.split(":").head.toInt) > 0 && near_stable_contain_trough_max < 0.15))
            && peak_near_stable_1st_mean / near_stable_1st_max > 4
            && near_stable_1st.split(":").last.toInt - near_stable_1st.split(":").head.toInt > 1
            && rank < 13) {
            val year_tide_list = 1.to(12).map(i => dwprbRecord(s"tide${if (i < 10) s"0$i" else s"$i"}"))
            row.append("1")
            row.appendAll(year_tide_list.map(x => s"'$x'"))

            year_tide_list.filter(x => x != null && !x.isEmpty).foreach(tide => {
              val tideHead = tide.split(",").head
              /*val dateRange = tideHead.split("\\[").last.replace("]", "")
              val start = dateRange.split("-").head
              val end = dateRange.split("-").last*/
              val index = tideHead.split("\\[").head
              val indexStart = index.split("-").head.toInt
              val indexEnd = index.split("-").last.toInt
              if ((indexStart > indexEnd && indexStart <= weekIndexHead) || (indexStart <= weekIndexHead && weekIndexTail <= indexEnd)) {
                tideType = tide.split(",")(1).toInt
              }
            })
          } else {
            row.append("0")
            1.to(12).foreach(_ => row.append(null))
          }

          if (tideType == -1)
            row.append(null)
          else
            row.append(tideType.toString)
        } else {
          19.to(35).foreach(_ => row.append(null))
        }*/
        21.to(37).foreach(_ => row.append(null))

        val somData = ListBuffer[String]()
        if (somMap.contains(key_string))
          somData.appendAll(somMap(key_string))

        if (somData.nonEmpty) {
          val merge_after_is_pure = somData.head
          val is_festival = somData(1)
          val silhouette_score = somData(2)
          val corr_score = somData(3)
          val categoryList = somData.slice(4, somData.length)
          row.append(merge_after_is_pure)
          row.append(is_festival)
          row.append(silhouette_score)
          row.append(if (corr_score.toLowerCase == "nan") null else corr_score)
          categoryList.foreach(category => {
            if (category.nonEmpty)
              row.append(s"'${"'\\d':\\s*\\d".r.findAllIn(category).map(_.substring(1, 2)).toList.sorted.mkString("")}'")
            else
              row.append(null)
          })
          somData.appendAll(row.slice(row.length - 4, row.length))
        } else {
          38.to(45).foreach(_ => row.append(null))
        }

        val somDayListSeq = somData.slice(somData.length - 4, somData.length).map(dayList => {
          if (dayList == null)
            List.empty[Int]
          else
            dayList.replaceAll("'", "").map(_.toString.toInt)
        })

        // mean
        val dayPatternMap = mutable.HashMap[Int, Int]()
        if (somDayListSeq.exists(_.nonEmpty) && dwprbData.contains(key)) {
          val dwprbRows = dwprbData(key)
          val daySeqMeanMap = mutable.LinkedHashMap[Seq[Int], Float]()
          somDayListSeq.foreach(dayList => {
            if (dayList.nonEmpty) {
              val meanValues = dayList.flatMap(day_of_week => {
                dwprbRows.filter(_.getInt(3) == day_of_week).map(_.getFloat(5))
              })
              daySeqMeanMap(dayList) = meanValues.sum / meanValues.length
            }
          })
          val sortedDaySeqMean = daySeqMeanMap.toList.sortBy(_._2)
          sortedDaySeqMean.indices.foreach(i => {
            val kv = sortedDaySeqMean(i)
            kv._1.foreach(day => dayPatternMap(day) = i + 1)
          })
        }

        // week_pattern
        // 对应的值越大表明其均值越高
        // 如:2222211指周一到周五为一类,且比周末的均值高
        val dayListSeq = if (dayPatternMap.isEmpty) {
          row.append(null)
          1.to(4).map(_ => List.empty[Seq[Int]])
        } else {
          row.append(s"'${dayPatternMap.toList.sortBy(_._1).map(_._2).mkString("")}'")
          val subDayListSeq = dayPatternMap.groupBy(_._2).mapValues(subMap => subMap.keys.toList.sorted).toList.sortBy(_._1).map(_._2)
          subDayListSeq ++ subDayListSeq.length.until(4).map(_ => List.empty[Seq[Int]])
        }

        if (maxactData.contains(key)) {
          // 中近期特征
          val maxactRows = maxactData(key)
          val maxactmaxValues = maxactRows.map(maxactRow => {
            maxactRow.getFloat(4)
          })
          val zero_actuser_day = maxactmaxValues.count(_ == 0)
          val less_actuser_day = maxactmaxValues.count(x => if ("室内" == is_indoor) 0 <= x && x < 2 else 0 <= x && x < 3)
          val more_actuser_day = maxactmaxValues.count(_ > 60)
          row.append(zero_actuser_day.toString)
          row.append(less_actuser_day.toString)
          row.append(more_actuser_day.toString)

          // zero_actuser
          // less_actuser
          val maxactIndexRange = 5.to(6)
          maxactIndexRange.foreach(idx => {
            dayListSeq.foreach(dayList => {
              if (dayList.nonEmpty) {
                val targetDataRows = maxactRows.filter(dataRow => dayList.contains(dataRow.getInt(3)))
                val periods = targetDataRows.filter(dataRow => dataRow.getString(idx) != null && dataRow.getString(idx).nonEmpty).flatMap(_.getString(idx).split(","))
                val hourList = calculateHourList(periods, targetDataRows.length)
                if (hourList.nonEmpty) {
                  row.append(s"'${humanReadblePeriods(gather(hourList))}'")
                } else {
                  row.append(null)
                }
              } else {
                row.append(null)
              }
            })
          })
        } else {
          47.to(57).foreach(_ => row.append(null))
        }

        if (dwprbData.contains(key)) {
          val dwprbRows = dwprbData(key)
          val dwprbmaxValues = dwprbRows.map(dwprbRow => {
            dwprbRow.getFloat(4)
          })
          row.append(dwprbmaxValues.count(_ <= 0.05f).toString)
          row.append(dwprbmaxValues.count(_ <= 0.1f).toString)
          row.append(dwprbmaxValues.count(_ >= 0.6f).toString)

          val dwprbIndexRange = 30.to(40)
          // low1~low7
          // trough_dwprb
          // peak_dwprb
          // near_stable_1st_dwprb
          // near_stable_contain_trough_dwprb
          val near_stable_1st_pubList = mutable.ListBuffer[String]()
          dwprbIndexRange.foreach(idx => {
            dayListSeq.foreach(dayList => {
              if (dayList.nonEmpty) {
                val targetDataRows = dwprbRows.filter(dataRow => dayList.contains(dataRow.getInt(3)))
                val periods = targetDataRows.filter(dataRow => dataRow.getString(idx) != null && dataRow.getString(idx).nonEmpty).flatMap(_.getString(idx).split(","))
                val hourList = calculateHourList(periods, targetDataRows.length)
                if (hourList.nonEmpty) {
                  val pubHour = gather(hourList)
                  if (idx == 39) {
                    near_stable_1st_pubList.append(pubHour)
                  }
                  row.append(s"'${humanReadblePeriods(pubHour)}'")
                } else {
                  if (idx == 39) {
                    near_stable_1st_pubList.append("")
                  }
                  row.append(null)
                }
              } else {
                if (idx == 39) {
                  near_stable_1st_pubList.append("")
                }
                row.append(null)
              }
            })
          })
          // mean
          dayListSeq.foreach(dayList => {
            if (dayList.nonEmpty) {
              val meanValues = dayList.flatMap(day_of_week => {
                dwprbRows.filter(dataRow => dataRow.getInt(3) == day_of_week).map(_.getFloat(5))
              })
              row.append((meanValues.sum / meanValues.length).toString)
            } else {
              row.append(null)
            }
          })

          val subValuesSeq = mutable.ListBuffer[Seq[Float]]()
          near_stable_1st_pubList.indices.foreach(i => {
            val near_stable_1st_pub = near_stable_1st_pubList(i)
            // near_stable_1st_pub 有可能为0
            if (near_stable_1st_pub.length > 1) {
              val hourList = periodToList(near_stable_1st_pub)
              val dayList = dayListSeq(i)
              val targetDataRows = dwprbRows.filter(dataRow => dayList.contains(dataRow.getInt(3)))
              val subValues = targetDataRows.flatMap(dataRow => hourList.map(hour => {
                if (dataRow.isNullAt(hour + 6))
                  -1
                else
                  dataRow.getFloat(hour + 6)
              })).filterNot(_ == -1)
              subValuesSeq.append(subValues)
            } else {
              subValuesSeq.append(List.empty[Float])
            }
          })
          // 1st_mean
          subValuesSeq.foreach(subValues => if (subValues.isEmpty) row.append(null) else row.append((subValues.sum / subValues.length).toString))
          // 1st_max
          subValuesSeq.foreach(subValues => if (subValues.isEmpty) row.append(null) else row.append(subValues.max.toString))
          // save hours
          val saveHourList = mutable.ListBuffer[String]()
          saveHourList.appendAll(List.fill(7)(null))
          if (dayListSeq.flatten.nonEmpty) {
            for (i <- dayListSeq.indices) {
              val dayList = dayListSeq(i)
              val near_stable_1st_pub = near_stable_1st_pubList(i)
              if (near_stable_1st_pub.length > 1) {
                dayList.foreach(day => saveHourList(day.asInstanceOf[Int] - 1) = s"'${humanReadblePeriods(near_stable_1st_pub)}'")
              }
            }
          }
          row.appendAll(saveHourList)
        } else {
          58.to(123).foreach(_ => row.append(null))
        }

        row.append(middleEnd)
        sqlClause.append(s"(${row.mkString(",").replaceAll("'null'", "null")})")
      }
    })

    logger.info(s"sector count:[${sectorList.size}]")
    logger.info(s"som count:[${somMap.size}]")
    logger.info(s"$sectorTable does not contains:[${somMap.keySet.map(key => (key._1.toInt, key._2.toInt)).diff(sectorList.keySet).mkString(",")}]")
    logger.info(s"frt count:[${sqlClause.size}]")

    middleEndCal.add(Calendar.DATE, 1)
    val partitionPlus = dateFmt.format(middleEndCal.getTime)
    val partition = s"p$middleEnd"
    if (existsPartition(mysqlStmt, targetTable, partition))
      mysqlStmt.execute(s"alter table `$targetTable` drop partition $partition")
    mysqlStmt.execute(s"alter table `$targetTable` add partition (partition $partition values less than ($partitionPlus) ENGINE = InnoDB)")
    mysqlConnect.commit()

    val insertColumns = insertFields.map(field => field._1)
    val pageCount = sqlClause.length / pageSize
    0.to(pageCount).foreach(page => {
      val sql = s"insert into `$targetTable` (${insertColumns.mkString(",")}) values ${sqlClause.slice(page * pageSize, (page + 1) * pageSize).mkString(",")}"
      try {
        mysqlStmt.execute(sql)
        mysqlConnect.commit()
      } catch {
        case e: Exception => logger.error(s"[${e.getMessage}]:[$sql]")
      }
    })

    mysqlStmt.close()
    mysqlConnect.close()
    spark.stop()
  }

  def loadSomData(spark: SparkSession, table: String, day: Int): Map[(String, String), Seq[String]] = {
    val sql = s"SELECT `base_statn_id`, `cell_id`, `merge_after_is_pure`, `is_festival`, `silhouette_score`, `corr_score`, `c9`, `c10`, `c11`, `c12` FROM $table where day = $day"
    val df = spark.sql(sql)
    val encoder = Encoders.tuple(Encoders.tuple(Encoders.STRING, Encoders.STRING), RowEncoder(df.schema))
    df.map(row => ((row.getString(0), row.getString(1)), row))(encoder).collect().toMap.mapValues(row => {
      List(
        row.getString(2),
        row.getString(3),
        row.getString(4),
        row.getString(5),
        row.getString(6),
        row.getString(7),
        row.getString(8),
        row.getString(9)
      )
    })
  }
}
