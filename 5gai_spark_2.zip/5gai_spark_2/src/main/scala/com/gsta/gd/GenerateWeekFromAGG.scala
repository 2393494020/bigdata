package com.gsta.gd

import java.util.Calendar

import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

import scala.collection.mutable

object GenerateWeekFromAGG extends Util with Serializable {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    val kpiTable = args(0).split(":").head
    val kpiField = args(0).split(":")(1)
    val fieldType = args(0).split(":").last.toLowerCase()
    val savePath = args(1)
    val numPartitions = args(2).toInt

    val directList = savePath.split("/")
    val day = directList.last

    val calendar = Calendar.getInstance()
    calendar.setTime(dateFmt.parse(day))
    calendar.add(Calendar.DATE, -(dayOfWeek(calendar) + 6))

    val monday = dateFmt.format(calendar.getTime)

    calendar.add(Calendar.DATE, 6)
    val sunday = dateFmt.format(calendar.getTime)

    val spark = SparkSession.builder().appName("5GAI-generate-week-data").enableHiveSupport().getOrCreate()
    val sc = spark.sparkContext

    val rows = mutable.ListBuffer[String]()

    val regionList = generateRegionList(spark, kpiTable, monday.toInt, sunday.toInt)
    logger.info(s"region list:[${regionList.map(x => s"${x._1}->${x._2}").mkString(",")}]")

    for (region <- regionList.map(_._1)) {
      val lastCount = rows.length
      val kpiData = generateKpiData(spark, kpiTable, kpiField, region, monday.toInt, sunday.toInt)
      kpiData.foreach(kv => {
        val row = generateSectorInfoFromKpi(kv._2.head)

        val dateHourDataMap =
          if (fieldType == "long")
            kv._2.map(row => (row.getLong(5), row.getLong(6).toFloat)).toMap
          else if (fieldType == "double")
            kv._2.map(row => (row.getLong(5), row.getDouble(6).toFloat)).toMap
          else
            kv._2.map(row => (row.getLong(5), row.getFloat(6))).toMap

        if (dateHourDataMap.nonEmpty) {
          val tweekValues = dateHourDataMap.values
          row.append(tweekValues.min.toString)
          row.append(tweekValues.max.toString)

          val calendar = Calendar.getInstance()
          calendar.setTime(dateFmt.parse(monday))
          1.to(7).foreach(_ => {
            val subValues = mutable.ListBuffer[Float]()
            0.to(23).foreach(_ => {
              val dateHour = dateHourFmt.format(calendar.getTime).toLong
              if (dateHourDataMap.contains(dateHour)) {
                subValues.append(dateHourDataMap(dateHour))
              } else {
                subValues.append(-1)
              }
              calendar.add(Calendar.HOUR, 1)
            })

            if (subValues.count(_ == -1) == 24) {
              row.appendAll(List("", "", "", ""))
            } else {
              val subMin = subValues.filterNot(_ == -1).min
              val subMax = subValues.filterNot(_ == -1).max
              row.append(subMin.toString)
              row.append(subMax.toString)
              row.append(fmt2Bit(subValues.indexOf(subMax)))
              row.append(fmt2Bit(subValues.indexOf(subMin)))
            }
          })
          val province = row.remove(0)
          row.append(province)
          rows.append(row.mkString("|").replaceAll("'", "").replaceAll("null", ""))
        }
      })
      logger.info(s"$region $monday-$sunday generates ${rows.length - lastCount} rows $kpiField data")
    }

    val hdfsPath = (directList.slice(0, directList.length - 1) ++ Array(monday)).mkString("/")
    val fs = FileSystem.get(sc.hadoopConfiguration)
    if (fs.exists(new Path(hdfsPath)))
      fs.delete(new Path(hdfsPath), true)

    sc.hadoopConfiguration.set("mapred.output.compress", "false")
    sc.parallelize(rows).repartition(numPartitions).saveAsTextFile(hdfsPath)

    spark.sql("set hive.exec.dynamic.partition=true")
    spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
    spark.sql("use savener")
    spark.sql(s"alter table ${directList(directList.length - 2)} add IF NOT EXISTS partition(day=$monday) location '$monday/'")

    logger.info(s"$monday-$sunday generates ${rows.length} rows $kpiField data")

    spark.stop()
  }
}
