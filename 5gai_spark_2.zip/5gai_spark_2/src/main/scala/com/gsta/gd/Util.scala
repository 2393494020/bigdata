package com.gsta.gd

import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.{Encoders, Row, SparkSession}
import org.slf4j.LoggerFactory

import scala.collection.mutable

trait Util extends com.gsta.Util {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def generateRegionList(spark: SparkSession, kpiTable: String, dayBegin: Int, dayEnd: Int): Array[(Int, String)] = {
    val sql =
      s"""
         |select distinct region_id, region_name
         |from $kpiTable
         |where day >= $dayBegin and day <= $dayEnd and region_id is not null order by region_id
            """.stripMargin.split("\\s+").map(_.trim).filter(_.length > 0).mkString(" ")
    spark.sql(sql).map(row => (row.getInt(0), row.getString(1)))(Encoders.tuple(Encoders.scalaInt, Encoders.STRING)).collect()
  }

  def generateKpiData(spark: SparkSession, kpiTable: String, field: String, region: Int, dayBegin: Int, dayEnd: Int): collection.Map[(Int, Int), Iterable[Row]] = {
    val sql =
      s"""
         |select distinct province_id, region_id, related_enb_id, cel_id, region_name, hour, $field
         |from $kpiTable
         |where day >= $dayBegin and day <= $dayEnd and region_id = $region
         |and $field is not NULL
            """.stripMargin.split("\\s+").map(_.trim).filter(_.length > 0).mkString(" ")
    spark.sql(sql).rdd.groupBy(row => (row.getString(2).toInt, row.getString(3).toInt)).collectAsMap()
  }

  def generateKpiData(spark: SparkSession, kpiTable: String, field: String, region: Int, dateHourList: Seq[Long]): collection.Map[(Int, Int), Iterable[Row]] = {
    val sql =
      s"""
         |select distinct province_id, region_id, related_enb_id, cel_id, region_name, hour, $field
         |from $kpiTable
         |where hour >= ${dateHourList.head} and hour <= ${dateHourList.last} and region_id = $region
         |and $field is not NULL
            """.stripMargin.split("\\s+").map(_.trim).filter(_.length > 0).mkString(" ")
    spark.sql(sql).rdd.groupBy(row => (row.getString(2).toInt, row.getString(3).toInt)).collectAsMap()
  }

  def generateWeekMinMaxData(spark: SparkSession, hiveTable: String, columnPrefix: String, day: Int): collection.Map[(Int, Int), (Float, Float)] = {
    val sql = s"select base_statn_id, cell_id, ${columnPrefix}min, ${columnPrefix}max from $hiveTable where day = $day"
    val df = spark.sql(sql)
    val encoder = Encoders.tuple(Encoders.tuple(Encoders.scalaInt, Encoders.scalaInt), Encoders.tuple(Encoders.scalaFloat, Encoders.scalaFloat))
    df.map(row => ((row.getInt(0), row.getInt(1)), (row.getFloat(2), row.getFloat(3))))(encoder).collect().toMap
  }

  def generateDimSectorData(spark: SparkSession, table: String, day: Int): collection.Map[(Int, Int), Row] = {
    val sectorSql = s"select distinct city_id, base_statn_id, base_statn_name, cell_id, cell_name, bs_vendor, is_indoor, band, nettype, city_name, cover_hotspot_type, nb_flag, band_width from $table where day = $day and cell_id is not null and city_id is not null"
    val df = spark.sql(sectorSql)
    val encoder = Encoders.tuple(Encoders.tuple(Encoders.scalaInt, Encoders.scalaInt), RowEncoder(df.schema))
    df.map(row => ((row.getInt(1), row.getInt(3)), row))(encoder).collect().toMap
  }

  override def generateDimSectorInfo(sector: Row): mutable.ListBuffer[String] = {
    val city_id = sector.getInt(0).toString
    val base_statn_id = sector.getInt(1).toString
    val base_statn_name = sector.getString(2)
    val cell_id = sector.getInt(3).toString
    val cell_name = sector.getString(4)
    val bs_vendor = sector.getString(5)
    val is_indoor = sector.getString(6)
    val band = sector.getString(7)
    val network = sector.getString(8)
    val region = sector.getString(9)
    val cover_hotspot_type = if (sector.isNullAt(10)) null else sector.getInt(10).toString
    val nb_flag = if (sector.isNullAt(11)) null else sector.getByte(11).toString
    val band_width = if (sector.isNullAt(12)) null else sector.getInt(12).toString
    val rru_rxport_num = null // if (sector.isNullAt(13)) null else sector.getInt(13).toString
    val rru_txport_num = null // if (sector.isNullAt(14)) null else sector.getInt(14).toString

    mutable.ListBuffer[String](city_id, base_statn_id, s"'$base_statn_name'", cell_id, s"'$cell_name'", s"'$bs_vendor'", s"'$is_indoor'", s"'$band'", s"'$network'", s"'$region'", cover_hotspot_type, nb_flag, band_width, rru_rxport_num, rru_txport_num)
  }

  override def generateDimSectorInfoFromDay(sector: Row): mutable.ListBuffer[String] = {
    val province_id = sector.getInt(0).toString
    val city_id = sector.getInt(1).toString
    val base_statn_id = sector.getInt(2).toString
    val base_statn_name = sector.getString(3)
    val cell_id = sector.getInt(4).toString
    val cell_name = sector.getString(5)
    val bs_vendor = sector.getString(6)
    val is_indoor = sector.getString(7)
    val band = sector.getString(8)
    val network = sector.getString(9)
    val region = sector.getString(10)
    val cover_hotspot_type = if (sector.isNullAt(11)) null else sector.getInt(11).toString
    val nb_flag = if (sector.isNullAt(12)) null else sector.getByte(12).toString
    val band_width = if (sector.isNullAt(13)) null else sector.getInt(13).toString

    mutable.ListBuffer[String](province_id, city_id, base_statn_id, s"'$base_statn_name'", cell_id, s"'$cell_name'", s"'$bs_vendor'", s"'$is_indoor'", s"'$band'", s"'$network'", s"'$region'", cover_hotspot_type, nb_flag, band_width)
  }

  override def generateSectorInfoFromKpi(kpiRow: Row): mutable.ListBuffer[String] = {
    val province_id = kpiRow.getInt(0).toString
    val city_id = kpiRow.getInt(1).toString
    val base_statn_id = kpiRow.getString(2)
    val cell_id = kpiRow.getString(3)
    val region = kpiRow.getString(4)

    mutable.ListBuffer[String](province_id, city_id, base_statn_id, "", cell_id, "", "", "", "", "", region, null, null, null)
  }
}
