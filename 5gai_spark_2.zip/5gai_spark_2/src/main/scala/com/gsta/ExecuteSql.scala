package com.gsta

import org.apache.spark.sql.SparkSession

object ExecuteSql {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("5GAI-test").enableHiveSupport().getOrCreate()
    spark.sql(args(0)).show()
  }
}
