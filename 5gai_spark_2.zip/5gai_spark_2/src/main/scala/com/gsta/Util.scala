package com.gsta

import java.sql.Statement
import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkContext
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.{Encoders, Row, SparkSession}
import org.slf4j.LoggerFactory

import scala.collection.immutable.HashMap
import scala.collection.mutable
import scala.util.control.Breaks.{break, breakable}

trait Util {
  private val logger = LoggerFactory.getLogger(this.getClass)

  val dateFmt = new SimpleDateFormat("yyyyMMdd")
  val dateHourFmt = new SimpleDateFormat("yyyyMMddHH")
  val host_port = "10.17.35.114:3306"
  val db = "5gai"
  val user = "5gai"
  val password = "5G_ai_2019"
  val mysqlJdbcUrl = s"jdbc:mysql://$host_port/$db?user=$user&password=$password&useSSL=false&rewriteBatchedStatements=true"
  // val user = "EnergySaving5G"
  // val password = "E_s_5g_2019"
  // val mysqlJdbcUrl = s"jdbc:mysql://192.168.9.223:3306/energydB?user=$user&password=$password&useSSL=false&rewriteBatchedStatements=true"
  val mysqlDriver = "com.mysql.jdbc.Driver"
  val dataDir = "/DATA/PUBLIC/NOCE/AGG/AGG_WIRELESS_KPI_CELL_H"

  val hourDelimiter = "-"

  @Deprecated
  def generateKpiData(sc: SparkContext, dateHourList: Seq[String], fields: Seq[(String, String)], field: String, sectorMap: collection.Map[(String, String), Row]): collection.Map[(String, String), Iterable[Row]] = {
    val fs = FileSystem.get(sc.hadoopConfiguration)
    sc.union(
      dateHourList.filter(dateHour => fs.exists(new Path(s"$dataDir/hour=$dateHour"))).map(dateHour => {
        sc.textFile(s"$dataDir/hour=$dateHour").map(line => {
          val row = kpiTextLine2MapRow(line, fields)
          Row(row("enodebid"), row("cellid"), dateHour, row(field).toFloat)
        })
      })
    ).filter(row => {
      val enodebid = row.getString(0)
      val cellid = row.getString(1)
      val fieldValue = row.getFloat(3)
      isInteger(enodebid) && isInteger(cellid) && (if ("dw_prb_userate" == field || "up_prb_userate" == field) fieldValue > 0 else fieldValue >= 0) && sectorMap.contains((enodebid, cellid))
    }).groupBy(row => (row.getString(0), row.getString(1))).collectAsMap()
  }

  @Deprecated
  def generateKpiData(spark: SparkSession, sectorTable: String, sectorDay: Int, kpiTable: String, field: String, dateHourList: Seq[Long]): collection.Map[(Int, Int), Iterable[Row]] = {
    val sql =
      s"""
         |select distinct base_statn_id, cell_id, hour, $field
         |from $kpiTable a, $sectorTable b
         |where a.enodebid = b.base_statn_id and a.cellid = b.cell_id
         |and b.day = $sectorDay
         |and a.hour >= ${dateHourList.head} and a.hour <= ${dateHourList.last}
         |and a.$field is not NULL and b.city_id is not null and b.base_statn_id is not NULL and b.cell_id is not NULL
            """.stripMargin.split("\\s+").map(_.trim).filter(_.length > 0).mkString(" ")
    spark.sql(sql).rdd.groupBy(row => (row.getInt(0), row.getInt(1))).collectAsMap()
  }

  def generateRegionList(spark: SparkSession, kpiTable: String, province: Int, dayBegin: Int, dayEnd: Int): Array[(Int, String)] = {
    val sql =
      s"""
         |select distinct region_id, region_name
         |from $kpiTable
         |where province_id = $province and day >= $dayBegin and day <= $dayEnd and region_id is not null order by region_id
            """.stripMargin.split("\\s+").map(_.trim).filter(_.length > 0).mkString(" ")
    spark.sql(sql).map(row => (row.getInt(0), row.getString(1)))(Encoders.tuple(Encoders.scalaInt, Encoders.STRING)).collect()
  }

  def generateKpiData(spark: SparkSession, kpiTable: String, field: String, province: Int, region: Int, dayBegin: Int, dayEnd: Int): collection.Map[(Int, Int), Iterable[Row]] = {
    val sql =
      s"""
         |select distinct region_id, related_enb_id, cel_id, region_name, hour, $field
         |from $kpiTable
         |where province_id = $province and day >= $dayBegin and day <= $dayEnd and region_id = $region
         |and $field is not NULL
            """.stripMargin.split("\\s+").map(_.trim).filter(_.length > 0).mkString(" ")
    spark.sql(sql).rdd.groupBy(row => (row.getString(1).toInt, row.getString(2).toInt)).collectAsMap()
  }

  def generateKpiData(spark: SparkSession, kpiTable: String, field: String, province: Int, region: Int, dateHourList: Seq[Long]): collection.Map[(Int, Int), Iterable[Row]] = {
    val sql =
      s"""
         |select distinct region_id, related_enb_id, cel_id, region_name, hour, $field
         |from $kpiTable
         |where province_id = $province and region_id = $region and hour >= ${dateHourList.head} and hour <= ${dateHourList.last}
         |and $field is not NULL
            """.stripMargin.split("\\s+").map(_.trim).filter(_.length > 0).mkString(" ")
    spark.sql(sql).rdd.groupBy(row => (row.getString(1).toInt, row.getString(2).toInt)).collectAsMap()
  }

  def generateWeekMinMaxData(spark: SparkSession, hiveTable: String, columnPrefix: String, province: Int, day: Int): collection.Map[(Int, Int), (Float, Float)] = {
    val sql = s"select base_statn_id, cell_id, ${columnPrefix}min, ${columnPrefix}max from $hiveTable where province_id = $province and day = $day"
    val df = spark.sql(sql)
    val encoder = Encoders.tuple(Encoders.tuple(Encoders.scalaInt, Encoders.scalaInt), Encoders.tuple(Encoders.scalaFloat, Encoders.scalaFloat))
    df.map(row => ((row.getInt(0), row.getInt(1)), (row.getFloat(2), row.getFloat(3))))(encoder).collect().toMap
  }

  def generateDimSectorData(spark: SparkSession, table: String, province: Int, day: Int): collection.Map[(Int, Int), Row] = {
    val sectorSql = s"select distinct city_id, base_statn_id, base_statn_name, cell_id, cell_name, bs_vendor, is_indoor, band, nettype, city_name, cover_hotspot_type, nb_flag, band_width, rru_rxport_num, rru_txport_num from $table where province_id = $province and day = $day and cell_id is not null and city_id is not null"
    val df = spark.sql(sectorSql)
    val encoder = Encoders.tuple(Encoders.tuple(Encoders.scalaInt, Encoders.scalaInt), RowEncoder(df.schema))
    df.map(row => ((row.getInt(1), row.getInt(3)), row))(encoder).collect().toMap
  }

  def generateDimSectorInfo(sector: Row): mutable.ListBuffer[String] = {
    val city_id = sector.getInt(0).toString
    val base_statn_id = sector.getInt(1).toString
    val base_statn_name = sector.getString(2)
    val cell_id = sector.getInt(3).toString
    val cell_name = sector.getString(4)
    val bs_vendor = sector.getString(5)
    val is_indoor = sector.getString(6)
    val band = sector.getString(7)
    val network = sector.getString(8)
    val region = sector.getString(9)
    val cover_hotspot_type = if (sector.isNullAt(10)) null else sector.getInt(10).toString
    val nb_flag = if (sector.isNullAt(11)) null else sector.getByte(11).toString
    val band_width = if (sector.isNullAt(12)) null else sector.getInt(12).toString
    val rru_rxport_num = if (sector.isNullAt(13)) null else sector.getInt(13).toString
    val rru_txport_num = if (sector.isNullAt(14)) null else sector.getInt(14).toString

    mutable.ListBuffer[String](city_id, base_statn_id, s"'$base_statn_name'", cell_id, s"'$cell_name'", s"'$bs_vendor'", s"'$is_indoor'", s"'$band'", s"'$network'", s"'$region'", cover_hotspot_type, nb_flag, band_width, rru_rxport_num, rru_txport_num)
  }

  def generateDimSectorInfoFromDay(sector: Row): mutable.ListBuffer[String] = {
    val city_id = sector.getInt(0).toString
    val base_statn_id = sector.getInt(1).toString
    val base_statn_name = sector.getString(2)
    val cell_id = sector.getInt(3).toString
    val cell_name = sector.getString(4)
    val bs_vendor = sector.getString(5)
    val is_indoor = sector.getString(6)
    val band = sector.getString(7)
    val network = sector.getString(8)
    val region = sector.getString(9)
    val cover_hotspot_type = if (sector.isNullAt(10)) null else sector.getInt(10).toString
    val nb_flag = if (sector.isNullAt(11)) null else sector.getByte(11).toString
    val band_width = if (sector.isNullAt(12)) null else sector.getInt(12).toString

    mutable.ListBuffer[String](city_id, base_statn_id, s"'$base_statn_name'", cell_id, s"'$cell_name'", s"'$bs_vendor'", s"'$is_indoor'", s"'$band'", s"'$network'", s"'$region'", cover_hotspot_type, nb_flag, band_width)
  }

  def generateSectorInfoFromKpi(kpiRow: Row): mutable.ListBuffer[String] = {
    val city_id = kpiRow.getInt(0).toString
    val base_statn_id = kpiRow.getString(1)
    val cell_id = kpiRow.getString(2)
    val region = kpiRow.getString(3)

    mutable.ListBuffer[String](city_id, base_statn_id, "", cell_id, "", "", "", "", "", region, null, null, null)
  }

  def kpiTextLine2MapRow(line: String, fields: Seq[(String, String)]): Map[String, String] = {
    val values = line.split(s"\\|", -1)
    val row = mutable.HashMap[String, String]()
    for (i <- fields.indices) {
      val (key, dataType) = fields(i)
      if (values.length <= i) {
        if ("string" == dataType)
          row(key) = ""
        else
          row(key) = "-1"
      } else {
        row(key) = if (values(i).trim == "\\N") "-1" else values(i).trim
      }
    }
    row.toMap
  }

  def increaseOrDecrease(values: Seq[Float]): Boolean = {
    // 顺序
    val ascSeq = values.sorted
    var asc = true
    values.indices.foreach(i => {
      if (ascSeq(i) != values(i))
        asc = false
    })

    if (asc) {
      asc
    } else {
      val descSeq = ascSeq.reverse
      var desc = true
      values.indices.foreach(i => {
        if (descSeq(i) != values(i))
          desc = false
      })
      desc
    }
  }

  def gatherContinueFlags(keyRange: Seq[Int], flagList: Seq[Int]): mutable.LinkedHashMap[Seq[Int], Int] = {
    val continueFlagMap = mutable.LinkedHashMap[String, Int]()
    var prev = flagList.head
    var i = 0
    var j = 1
    while (j < flagList.length) {
      if (prev != flagList(j)) {
        continueFlagMap(s"${fmt2Bit(keyRange(i))}:${fmt2Bit(keyRange(j - 1))}") = prev
        prev = flagList(j)
        i = j
      }
      j = j + 1
    }
    continueFlagMap(s"${fmt2Bit(keyRange(i))}:${fmt2Bit(keyRange(j - 1))}") = prev
    if (logger.isDebugEnabled) {
      logger.debug("合并连续的标记")
      continueFlagMap.foreach(kv => logger.debug(s"${kv._1}->${kv._2}"))
    }
    continueFlagMap.map(kv => {
      (periodToList(kv._1, keyRange.head, keyRange.last), kv._2)
    })
  }

  def gatherContinueFlagsCircle(keyRange: Seq[Int], flagList: Seq[Int]): mutable.LinkedHashMap[Seq[Int], Int] = {
    val continueFlagMap = gatherContinueFlags(keyRange, flagList)
    // 合并头尾
    if (continueFlagMap.size > 1 && continueFlagMap.head._2 == continueFlagMap.last._2 && continueFlagMap.head._1.head == keyRange.head && keyRange.last == continueFlagMap.last._1.last) {
      val headKey = continueFlagMap.head._1
      val tailKey = continueFlagMap.last._1

      val flag = continueFlagMap.last._2
      val newKey = tailKey ++ headKey

      continueFlagMap.remove(headKey)
      continueFlagMap.remove(tailKey)
      continueFlagMap(newKey) = flag
    }
    if (logger.isDebugEnabled) {
      logger.debug("合并头尾")
      continueFlagMap.foreach(kv => logger.debug(s"${kv._1}->${kv._2}"))
    }
    continueFlagMap
  }

  def combineCore(values: Seq[Float], eachCoreMap: mutable.LinkedHashMap[Int, Seq[Int]], valueKeyRange: Seq[Int], remainDiff: Boolean = true): Unit = {
    val stableSliceList = eachCoreMap.values.toList.distinct.sortWith((x, y) => {
      if (x.size == y.size) {
        val xvalues = x.map(values(_))
        val yvalues = y.map(values(_))
        if ((xvalues.sum / xvalues.length) < (yvalues.sum / yvalues.length))
          true
        else if (xvalues.max < yvalues.max)
          true
        else
          x.size > y.size
      } else {
        x.size > y.size
      }
    })

    val sortedStableSliceList = mutable.ListBuffer[Seq[Int]]()
    sortedStableSliceList.appendAll(stableSliceList)

    while (sortedStableSliceList.nonEmpty) {
      val lgSlice = sortedStableSliceList.head
      /*println(sortedStableSliceList)
      println(lgSlice)
      println(eachCoreMap)*/
      val sameKeySlice = mutable.ListBuffer[Int]()
      valueKeyRange.foreach(key => {
        if (eachCoreMap.contains(key)) {
          // 大平稳周期包含小平稳周期
          // 平稳周期两两相等
          val ltSlice = eachCoreMap(key)
          if (lgSlice.containsSlice(ltSlice)) {
            if (lgSlice.size > ltSlice.size)
              eachCoreMap.remove(key)
            else
              sameKeySlice.append(key)
          } else if (lgSlice.diff(ltSlice).length < lgSlice.length && lgSlice.length >= ltSlice.length) {
            // 大平稳周期与小平稳周期有交集
            val diff = ltSlice.diff(lgSlice)
            if (diff.contains(key)) {
              eachCoreMap.update(key, diff)
            } else {
              eachCoreMap.remove(key)
            }

            val idx = sortedStableSliceList.indexOf(ltSlice)
            if (idx > -1) {
              // if (diff.contains(key) || (remainDiff && eachCoreMap.values.count(slice => slice.mkString(",") == diff.mkString(",")) > 0) || (!remainDiff && eachCoreMap.values.count(_.mkString(",") == ltSlice.mkString(",")) > 0)) {
              val slice = if (remainDiff) {
                eachCoreMap.filter(kv => kv._2 == diff)
              } else {
                eachCoreMap.filter(kv => kv._2 == ltSlice)
              }
              if (diff.contains(key) || (slice.nonEmpty && slice.exists(kv => diff.contains(kv._1)))) {
                sortedStableSliceList(idx) = diff
              } else {
                sortedStableSliceList.remove(idx)
              }
            }
            /*println(ltSlice)
            println(idx)
            println(diff)
            println(key)*/
          }
        }
      })
      if (sameKeySlice.length > 1) {
        val valueKeySlice = eachCoreMap(sameKeySlice.head)
        val middleHour = if (sameKeySlice.length == valueKeySlice.length) valueKeySlice(valueKeySlice.length / 2) else sameKeySlice(sameKeySlice.length / 2)
        sameKeySlice.filterNot(_ == middleHour).foreach(idx => eachCoreMap.remove(idx))
      }
      sortedStableSliceList.remove(0)
      val remainStableSlice = sortedStableSliceList.distinct.sortWith((x, y) => {
        if (x.size == y.size) {
          val xvalues = x.map(values(_))
          val yvalues = y.map(values(_))
          if ((xvalues.sum / xvalues.length) < (yvalues.sum / yvalues.length))
            true
          else if (xvalues.max < yvalues.max)
            true
          else
            false
        } else {
          x.size > y.size
        }
      })
      sortedStableSliceList.clear()
      sortedStableSliceList.appendAll(remainStableSlice)
    }

    if (eachCoreMap.values.toList.distinct.flatten.length > valueKeyRange.length || eachCoreMap.values.toList.distinct.length < eachCoreMap.values.toList.length)
      combineCore(values, eachCoreMap, valueKeyRange)
  }

  // 切分平稳周期
  def splitValuesPro(wmax: Float, values: Seq[Float], valueKeyRange: Seq[Int], energySavingMinSize: Int): mutable.LinkedHashMap[Int, (Float, Seq[Float], Seq[Int])] = {
    if (logger.isDebugEnabled) logger.debug(values.mkString(","))
    val max = values.max
    val min = values.min
    val delta = 0.075f
    val continueDelta = (wmax - min) * 0.05f
    val skipDelta = (wmax - min) * 0.075f
    val coreRangeMap = mutable.LinkedHashMap[Int, Seq[Int]]()
    // if (max - min <= math.min(continueDelta, delta)) {
    if (max - min <= continueDelta) {
      coreRangeMap(valueKeyRange.head) = valueKeyRange
    } else {
      val eachCoreMap = mutable.LinkedHashMap[Int, Seq[Int]]()
      valueKeyRange.foreach(core => {
        // 往前垃
        val previous = mutable.ListBuffer[Int]()
        val previousIndices = generatePreviousIndices(core, valueKeyRange)
        // if (math.abs(values(core) - values(previousIndices.head)) <= math.min(continueDelta, delta)) {
        if (math.abs(values(core) - values(previousIndices.head)) <= continueDelta) {
          previous.append(previousIndices.head)
          breakable {
            for (hour <- previousIndices.slice(1, previousIndices.length)) {
              val previousHour = if (hour == valueKeyRange.last) valueKeyRange.head else hour + 1
              // val prevPlusCoreValues = previous.map(values(_)) ++ List(values(core), values(hour))
              if (math.abs(values(core) - values(hour)) <= skipDelta && math.abs(values(previousHour) - values(hour)) <= continueDelta /* && math.abs(prevPlusCoreValues.max - prevPlusCoreValues.min) <= delta*/ ) {
                previous.append(hour)
              } else {
                break
              }
            }
          }
        }
        // 往后垃
        val next = mutable.ListBuffer[Int]()
        val nextIndices = generateNextIndices(core, valueKeyRange)
        // if (math.abs(values(core) - values(nextIndices.head)) <= math.min(continueDelta, delta)) {
        if (math.abs(values(core) - values(nextIndices.head)) <= continueDelta) {
          next.append(nextIndices.head)
          breakable {
            for (hour <- nextIndices.slice(1, nextIndices.length)) {
              val previousHour = if (hour == valueKeyRange.head) valueKeyRange.last else hour - 1
              // val plusNextValues = previous.map(values(_)) ++ List(values(core)) ++ next.map(values(_)) ++ List(values(hour))
              if (math.abs(values(core) - values(hour)) <= skipDelta && math.abs(values(previousHour) - values(hour)) <= continueDelta /* && math.abs(plusNextValues.max - plusNextValues.min) <= delta*/ ) {
                next.append(hour)
              } else {
                break
              }
            }
          }
        }
        eachCoreMap(core) = (previous.reverse :+ core) ++ next
      })

      if (logger.isDebugEnabled) {
        logger.debug("每个时段各自拉取平稳周期")
        eachCoreMap.foreach(kv => {
          logger.debug(s"[${fmt2Bit(kv._1)}->[${kv._2.mkString(",")}]->[${kv._2.map(i => values(i)).mkString(",")}]]")
        })
      }

      val stableSliceList = eachCoreMap.values.toList.distinct
      if (stableSliceList.flatten.length > valueKeyRange.length) {
        if (stableSliceList.count(_.distinct.length == valueKeyRange.length) > 0) {
          // 一个核心周期拉全量
          coreRangeMap(eachCoreMap.filter(_._2.distinct.length == valueKeyRange.length).head._1) = valueKeyRange
        } else {
          // 大平稳周期包含小平稳周期
          // 两个平稳周期有交集
          // ************** 寻找潜在节能时段 start
          val stableSliceList = eachCoreMap.values.toList.distinct.sortWith((x, y) => {
            if (x.size == y.size) {
              val xvalues = x.map(values(_))
              val yvalues = y.map(values(_))
              if ((xvalues.sum / xvalues.length) < (yvalues.sum / yvalues.length))
                true
              else if (xvalues.max < yvalues.max)
                true
              else
                x.size > y.size
            } else {
              x.size > y.size
            }
          })

          if (stableSliceList.exists(segments => {
            val subValues = segments.map(values(_))
            subValues.sum / subValues.length <= 0.1 && subValues.max > 0.1
          })) {
            val savingListSeq = mutable.ListBuffer[Seq[Int]]()
            for (seg <- stableSliceList) {
              val subList = seg.map(values(_))
              if (subList.max <= 0.1 && subList.length >= energySavingMinSize && !savingListSeq.exists(_.containsSlice(seg))) {
                savingListSeq.append(seg)
              }
            }
            if (savingListSeq.nonEmpty) {
              logger.debug(s"潜在节能时段：[${savingListSeq.map(seg => s"[${seg.mkString(",")}]").mkString(",")}]")
              for (savingList <- savingListSeq) {
                for (kv <- eachCoreMap) {
                  // 分解
                  if (kv._2.length > savingList.length && kv._2.containsSlice(savingList)) {
                    if (savingList.contains(kv._1))
                      eachCoreMap(kv._1) = savingList
                    else {
                      val headSliceIdx = kv._2.indexOf(savingList.head) + 1
                      val endSliceIdx = kv._2.indexOf(savingList.last) + 1
                      val headSlice = kv._2.slice(0, headSliceIdx)
                      val endSlice = kv._2.slice(endSliceIdx, kv._2.length)
                      if (headSlice.contains(kv._1))
                        eachCoreMap(kv._1) = headSlice
                      else
                        eachCoreMap(kv._1) = endSlice
                    }
                  }
                }
              }
            }

            if (logger.isDebugEnabled) {
              logger.debug("为寻找潜在节能时段重新分配平稳周期")
              eachCoreMap.foreach(kv => {
                logger.debug(s"[${fmt2Bit(kv._1)}->[${kv._2.mkString(",")}]->[${kv._2.map(i => values(i)).mkString(",")}]]")
              })
            }
          }
          // ************** 寻找潜在节能时段 end

          // 备份
          val eachCoreMapCopy = mutable.LinkedHashMap[Int, Seq[Int]]()
          for (kv <- eachCoreMap) {
            eachCoreMapCopy(kv._1) = kv._2
          }

          combineCore(values, eachCoreMap, valueKeyRange)
          if (eachCoreMap.values.toList.distinct.flatten.length < valueKeyRange.length) {
            combineCore(values, eachCoreMapCopy, valueKeyRange, remainDiff = false)
            eachCoreMapCopy.foreach(kv => {
              coreRangeMap(kv._1) = kv._2
            })
          } else {
            eachCoreMap.foreach(kv => {
              coreRangeMap(kv._1) = kv._2
            })
          }
        }
      } else {
        stableSliceList.foreach(valueKeySlice => {
          val core = valueKeySlice(valueKeySlice.length / 2)
          coreRangeMap(core) = valueKeySlice
        })
      }
    }

    logger.debug(s"核心周期及其拉取的平稳周期-${coreRangeMap.values.toList.distinct.flatten.length == valueKeyRange.length}")

    val finalCoreRangeMap = mutable.LinkedHashMap[Int, (Float, Seq[Float], Seq[Int])]()
    coreRangeMap.foreach(kv => {
      val subValues = kv._2.map(values(_))
      val coefficient = (subValues.max - min) / (wmax - min)
      finalCoreRangeMap(kv._1) = (coefficient, subValues, kv._2)
      logger.debug(s"[${fmt2Bit(kv._1)}->[${kv._2.mkString(",")}]->[${subValues.mkString(",")}]->[$coefficient]->[${subValues.sum / subValues.length}]]")
    })
    finalCoreRangeMap
  }

  // 环往前走
  def generatePreviousIndices(core: Int, valueKeyRange: Seq[Int]): Seq[Int] = {
    val prevRange = valueKeyRange.head.until(core)
    val nextRange = (core + 1).to(valueKeyRange.last)
    prevRange.reverse ++ nextRange.reverse
  }

  // 环往后走
  def generateNextIndices(core: Int, valueKeyRange: Seq[Int]): Seq[Int] = {
    val prevRange = valueKeyRange.head.until(core)
    val nextRange = (core + 1).to(valueKeyRange.last)
    nextRange ++ prevRange
  }

  // 切分平稳周期
  @Deprecated
  def splitValues(weekMax: Float, values: Seq[Float], valueKeyRange: Seq[Int]): mutable.LinkedHashMap[String, (Float, Seq[Float])] = {
    val headTail = s"${fmt2Bit(valueKeyRange.head)}:${fmt2Bit(valueKeyRange.last)}"
    val max = values.max
    val min = values.min
    val continueDelta = (weekMax - min) * 0.05f
    val skipDelta = (weekMax - min) * 0.075f

    val rangeValuesMap = mutable.LinkedHashMap[String, Seq[Float]]()
    if (max - min <= continueDelta) {
      rangeValuesMap(headTail) = values
    } else {
      var i = 0
      var j = 1
      var prev = values.head
      while (j < values.length) {
        val next = values(j)
        val segments = values.slice(i, j)
        if (math.abs(next - prev) <= continueDelta && math.abs(next - segments.max) <= skipDelta && math.abs(next - segments.min) <= skipDelta) {
          prev = next
        } else {
          val key = s"${fmt2Bit(valueKeyRange(i))}:${fmt2Bit(valueKeyRange(j - 1))}"
          rangeValuesMap(key) = values.slice(i, j)
          prev = next
          i = j
        }
        j = j + 1
      }

      val key = s"${fmt2Bit(valueKeyRange(i))}:${fmt2Bit(valueKeyRange(j - 1))}"
      rangeValuesMap(key) = values.slice(i, j)
    }

    val finalRangeValuesMap = mutable.LinkedHashMap[String, Seq[Float]]()
    if (rangeValuesMap.size > 1) {
      var headKey = rangeValuesMap.head._1
      var tailKey = rangeValuesMap.last._1

      var headSubValues = rangeValuesMap.head._2
      var tailSubValues = rangeValuesMap.last._2

      // [00:06]:[0.0682,0.0591,0.0525,0.0478,0.0497,0.0501,0.0548]
      // [20:23]:[0.0999,0.0873,0.0867,0.0797]
      while (headSubValues.nonEmpty && math.abs(tailSubValues.last - headSubValues.head) <= continueDelta && math.abs(tailSubValues.max - headSubValues.head) <= skipDelta && math.abs(tailSubValues.min - headSubValues.head) <= skipDelta) {
        tailSubValues = tailSubValues :+ headSubValues.head
        headSubValues = headSubValues.slice(1, headSubValues.length)
        tailKey = s"${tailKey.split(":").head}:${headKey.split(":").head}"
        headKey = s"${fmt2Bit(headKey.split(":").head.toInt + 1)}:${headKey.split(":").last}"
      }

      if (headSubValues.isEmpty) {
        if (rangeValuesMap.size == 2) {
          rangeValuesMap.clear()
          rangeValuesMap(headTail) = values
        } else {
          val headKey = rangeValuesMap.head._1
          val lastKey = rangeValuesMap.last._1
          val tailKey = s"${lastKey.split(":").head}:${headKey.split(":").last}"
          val tailValues = rangeValuesMap.last._2 ++ rangeValuesMap.head._2
          rangeValuesMap(tailKey) = tailValues
          rangeValuesMap.remove(headKey)
          rangeValuesMap.remove(lastKey)
        }
        rangeValuesMap.foreach(kv => {
          finalRangeValuesMap(kv._1) = kv._2
        })
      } else {
        rangeValuesMap.remove(rangeValuesMap.head._1)
        rangeValuesMap.remove(rangeValuesMap.last._1)
        finalRangeValuesMap(headKey) = headSubValues
        rangeValuesMap.foreach(kv => {
          finalRangeValuesMap(kv._1) = kv._2
        })
        finalRangeValuesMap(tailKey) = tailSubValues
      }
    } else {
      rangeValuesMap.foreach(kv => {
        finalRangeValuesMap(kv._1) = kv._2
      })
    }

    if (logger.isDebugEnabled) {
      logger.debug(s"[${values.mkString(",")}]")
      logger.debug(s"[min]:[$min]")
      logger.debug(s"[max]:[$max]")
      logger.debug(s"[weekMax]:[$weekMax]")
      finalRangeValuesMap.foreach(kv => {
        val (key, children) = kv
        val coefficient = (children.max - min) / (weekMax - min)
        logger.debug(s"[$key]:[$coefficient]:[${children.mkString(",")}]")
      })
    }

    finalRangeValuesMap.map(kv => {
      val (key, children) = kv
      val coefficient = (children.max - min) / (weekMax - min)
      (key, (coefficient, children))
    })
  }

  def baseCoefficient(values: Seq[Float], valueKeys: Seq[Int]): Seq[String] = {
    val row = mutable.ListBuffer[String]()
    val realValues = values.filter(_ > -1)
    val sum = if (values.count(_ == -1) > 0) 0 else values.sum
    val min = realValues.min
    val max = values.max

    row.append(min.toString)
    row.append(max.toString)
    row.append(if (sum == 0) null else sum.toString)

    val mean = realValues.sum / realValues.length
    row.append(mean.toString)
    row.append(realValues.sorted.toList(realValues.length / 2).toString)

    val variance = realValues.map(x => math.pow(x - mean, 2)).sum / realValues.length
    val std = math.sqrt(variance)
    row.append(variance.toString)
    row.append(std.toString)

    val kpiMaxIndex = values.indexWhere(_ == max)
    val kpiMinIndex = values.indexWhere(_ == min)
    row.append(s"'${fmt2Bit(valueKeys(kpiMaxIndex))}'")
    row.append(s"'${fmt2Bit(valueKeys(kpiMinIndex))}'")

    row.append(if (mean == 0) null else (std / mean).toString)

    row
  }

  def coefficientScore(coefficientMap: mutable.LinkedHashMap[Int, (Float, Seq[Float], Seq[Int])]): Seq[String] = {
    val valueKeys = coefficientMap.map(_._2._3).toList.flatten.sorted
    if (coefficientMap.size == 1) {
      valueKeys.map(_ => coefficientMap.head._2._1.toString)
    } else {
      val divideCoefficientMap = mutable.HashMap[String, Float]()
      coefficientMap.foreach(kv => {
        val (_, (coefficient, _, keys)) = kv
        keys.foreach(key => {
          divideCoefficientMap(key.toString) = coefficient
        })
      })

      // 所有周期潮汐系数
      valueKeys.map(key => {
        divideCoefficientMap(key.toString).toString
      })
    }
  }

  @Deprecated
  def coefficientScore(coefficientMap: mutable.LinkedHashMap[String, (Float, Seq[Float])], valueKeys: Seq[Int]): Seq[String] = {
    if (coefficientMap.size == 1) {
      valueKeys.map(_ => coefficientMap.head._2._1.toString)
    } else {
      val divideCoefficientMap = mutable.HashMap[String, Float]()
      coefficientMap.foreach(kv => {
        val (period, (coefficient, _)) = kv
        val keys = periodToList(period, valueKeys.head, valueKeys.last)
        keys.foreach(key => {
          divideCoefficientMap(key.toString) = coefficient
        })
      })

      // 24 小时潮汐系数
      valueKeys.map(key => {
        divideCoefficientMap(key.toString).toString
      })
    }
  }

  def coefficientPeak(coefficientMap: mutable.LinkedHashMap[Int, (Float, Seq[Float], Seq[Int])]): (String, Seq[String]) = {
    val values = mutable.ListBuffer[String]()
    // 最大系数是为波峰
    val coefficientTemp = coefficientMap.maxBy(_._2._1)._2._1
    val coefficientMax = coefficientMap.filter(_._2._1 == coefficientTemp).maxBy(_._2._2.size)
    // 波峰核心周期
    val peakCore = coefficientMax._1
    val peakValues = coefficientMax._2._2
    val peakKeys = coefficientMax._2._3
    val maxKey = s"${fmt2Bit(peakKeys.head)}:${fmt2Bit(peakKeys.last)}"
    // 波峰
    values.append(s"'$maxKey'")
    values.append((coefficientMax._2._2.sum / coefficientMax._2._2.length).toString)
    values.append(peakValues.max.toString)
    values.append(coefficientMax._2._1.toString)
    values.append(fmt2Bit(peakCore))
    logger.debug(s"[波峰->$maxKey]:[核心:$peakCore]:[${peakKeys.mkString(",")}]:[${peakValues.mkString(",")}]:[${coefficientMax._2._1}]")

    (maxKey, values)
  }

  @Deprecated
  def coefficientPeak(coefficientMap: mutable.LinkedHashMap[String, (Float, Seq[Float])], valueKeys: Seq[Int]): (String, Seq[String]) = {
    val values = mutable.ListBuffer[String]()
    // 最大系数是为波峰
    val coefficientTemp = coefficientMap.maxBy(_._2._1)._2._1
    val coefficientMax = coefficientMap.filter(_._2._1 == coefficientTemp).maxBy(_._2._2.size)
    // 波峰
    values.append(s"'${coefficientMax._1}'")
    values.append((coefficientMax._2._2.sum / coefficientMax._2._2.length).toString)
    values.append(coefficientMax._2._2.max.toString)
    values.append(coefficientMax._2._1.toString)
    // 波峰核心周期
    val maxKey = coefficientMax._1
    val peakValues = coefficientMax._2._2
    val peakKeys = periodToList(maxKey, valueKeys.head, valueKeys.last)
    logger.debug(s"[波峰]:[$maxKey]:[${peakKeys.mkString(",")}]:[${peakValues.mkString(",")}]")

    val peakCore = calculateCore(peakValues, peakKeys)
    values.append(s"'$peakCore'")
    logger.debug(s"[波峰核心]:[$peakCore]")

    (maxKey, values)
  }

  def coefficientTrough(coefficientMap: mutable.LinkedHashMap[Int, (Float, Seq[Float], Seq[Int])]): (String, Seq[String]) = {
    val values = mutable.ListBuffer[String]()
    // 最小系数是为波谷
    val coefficientTemp = coefficientMap.minBy(_._2._1)._2._1
    val coefficientMin = coefficientMap.filter(_._2._1 == coefficientTemp).maxBy(_._2._2.size)
    // 波谷核心周期
    val troughCore = coefficientMin._1
    val troughValues = coefficientMin._2._2
    val troughKeys = coefficientMin._2._3
    val minKey = s"${fmt2Bit(troughKeys.head)}:${fmt2Bit(troughKeys.last)}"
    // 波谷
    values.append(s"'$minKey'")
    values.append((coefficientMin._2._2.sum / coefficientMin._2._2.length).toString)
    values.append(coefficientMin._2._2.max.toString)
    values.append(coefficientMin._2._1.toString)
    values.append(fmt2Bit(troughCore))
    logger.debug(s"[波谷->$minKey]:[核心:$troughCore]:[${troughKeys.mkString(",")}]:[${troughValues.mkString(",")}]:[${coefficientMin._2._1}]")

    (minKey, values)
  }

  @Deprecated
  def coefficientTrough(coefficientMap: mutable.LinkedHashMap[String, (Float, Seq[Float])], valueKeys: Seq[Int]): (String, Seq[String]) = {
    val values = mutable.ListBuffer[String]()
    // 最小系数是为波谷
    val coefficientTemp = coefficientMap.minBy(_._2._1)._2._1
    val coefficientMin = coefficientMap.filter(_._2._1 == coefficientTemp).maxBy(_._2._2.size)
    // 波谷
    values.append(s"'${coefficientMin._1}'")
    values.append((coefficientMin._2._2.sum / coefficientMin._2._2.length).toString)
    values.append(coefficientMin._2._2.max.toString)
    values.append(coefficientMin._2._1.toString)
    // 波谷核心周期
    val minKey = coefficientMin._1
    val troughValues = coefficientMin._2._2
    val troughKeys = periodToList(minKey, valueKeys.head, valueKeys.last)
    logger.debug(s"[波谷]:[$minKey]:[${troughKeys.mkString(",")}]:[${troughValues.mkString(",")}]")

    val troughCore = calculateCore(troughValues, troughKeys)
    values.append(s"'$troughCore'")
    logger.debug(s"[波谷核心]:[$troughCore]")

    (minKey, values)
  }

  def nearStablePeak(coefficientMap: mutable.LinkedHashMap[String, (Float, Seq[Float])], valueKeys: Seq[Int], coefficientLimit: Float, condition: String, valueLimit: Float, minSize: Int): Seq[(String, Seq[Float])] = {
    // 取大致平稳周期
    // 按潮汐系数,最大值,小时数过滤
    val nearStableCoefficientMap = if ("coefficient" == condition) {
      coefficientMap.filter(_._2._1 >= coefficientLimit)
    } else if ("value" == condition) {
      coefficientMap.filter(_._2._2.max >= valueLimit)
    } else if ("and" == condition) {
      coefficientMap.filter(kv => kv._2._1 >= coefficientLimit && kv._2._2.max >= valueLimit)
    } else {
      coefficientMap.filter(kv => kv._2._1 >= coefficientLimit || kv._2._2.max >= valueLimit)
    }

    if (logger.isDebugEnabled) {
      logger.debug(s"按潮汐系数:[$coefficientLimit],最大值:[$valueLimit]过滤")
      logger.debug(s"[时段]:[均值]:[最大值]:[系数]:[时段对应值]")
      nearStableCoefficientMap.foreach(kv => {
        val (key, (coefficient, children)) = kv
        val childMean = children.sum / children.length
        logger.debug(s"[$key]:[$childMean]:[${children.max}]:[$coefficient]:[${children.mkString(",")}]")
      })
    }
    gather(nearStableCoefficientMap, valueKeys).filter(_._2.size >= minSize).toList.sortWith((x, y) => {
      if (x._2.length == y._2.length) {
        if ((x._2.sum / x._2.length) > (y._2.sum / y._2.length))
          true
        else if (x._2.max > y._2.max)
          true
        else
          false
      } else {
        x._2.size > y._2.size
      }
    })
  }

  def nearStableTrough(coefficientMap: mutable.LinkedHashMap[String, (Float, Seq[Float])], valueKeys: Seq[Int], coefficientLimit: Float, condition: String, valueLimit: Float, minSize: Int): Seq[(String, Seq[Float])] = {
    // 取大致平稳周期
    // 按潮汐系数,最大值,小时数过滤
    val nearStableCoefficientMap = if ("coefficient" == condition) {
      coefficientMap.filter(_._2._1 <= coefficientLimit)
    } else if ("value" == condition) {
      coefficientMap.filter(_._2._2.max <= valueLimit)
    } else if ("and" == condition) {
      coefficientMap.filter(kv => kv._2._1 <= coefficientLimit && kv._2._2.max <= valueLimit)
    } else {
      coefficientMap.filter(kv => kv._2._1 <= coefficientLimit || kv._2._2.max <= valueLimit)
    }

    if (logger.isDebugEnabled) {
      logger.debug(s"按潮汐系数:[$coefficientLimit],最大值:[$valueLimit]过滤")
      logger.debug(s"[时段]:[均值]:[最大值]:[系数]:[时段对应值]")
      nearStableCoefficientMap.foreach(kv => {
        val (key, (coefficient, children)) = kv
        val childMean = children.sum / children.length
        logger.debug(s"[$key]:[$childMean]:[${children.max}]:[$coefficient]:[${children.mkString(",")}]")
      })
    }
    gather(nearStableCoefficientMap, valueKeys).filter(_._2.size >= minSize).toList.sortWith((x, y) => {
      if (x._2.length == y._2.length) {
        if ((x._2.sum / x._2.length) < (y._2.sum / y._2.length))
          true
        else if (x._2.max < y._2.max)
          true
        else
          false
      } else {
        x._2.size > y._2.size
      }
    })
  }

  def gather(nearStableCoefficientMap: mutable.LinkedHashMap[String, (Float, Seq[Float])], valueKeys: Seq[Int]): Seq[(String, Seq[Float])] = {
    val headTail = s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}"
    // 01:04 -> (coefficient, [0.1, 0.2, 0.3, 0.4])
    // 05:06 -> (coefficient, [0.5, 0.6])
    // 合并后
    // 01:06 -> [0.1, 0.2, 0.3, 0.4, 0.5, 0.6]
    val nearStableValueList = mutable.LinkedHashMap[String, Seq[Float]]()
    if (nearStableCoefficientMap.nonEmpty) {
      var prev = nearStableCoefficientMap.head._1.split(":").last.toInt
      var start = 0
      var index = 1
      nearStableCoefficientMap.slice(1, nearStableCoefficientMap.size).foreach(kv => {
        val current = kv._1.split(":").head.toInt
        if (current - prev > 1) {
          val subList = nearStableCoefficientMap.slice(start, index).toList
          val key = s"${subList.head._1.split(":").head}:${subList.last._1.split(":").last}"

          nearStableValueList(key) = subList.flatMap(_._2._2)
          start = index
        }
        prev = kv._1.split(":").last.toInt
        index = index + 1
      })

      val subList = nearStableCoefficientMap.slice(start, index).toList
      val key = s"${subList.head._1.split(":").head}:${subList.last._1.split(":").last}"
      nearStableValueList(key) = subList.flatMap(_._2._2)

      if (nearStableValueList.size > 1) {
        val headKey = nearStableValueList.head._1
        val tailKey = nearStableValueList.last._1
        if ((headKey.split(":").head == fmt2Bit(valueKeys.head) && tailKey.split(":").last == fmt2Bit(valueKeys.last))
          || (headKey.split(":").head.toInt - tailKey.split(":").last.toInt == 1)) {
          val newKey = s"${tailKey.split(":").head}:${headKey.split(":").last}"
          val subList = nearStableValueList.last._2 ++ nearStableValueList.head._2
          nearStableValueList.remove(headKey)
          nearStableValueList.remove(tailKey)
          nearStableValueList(newKey) = subList
        }
      }

      if (nearStableValueList.size == 1 && nearStableValueList.head._2.size == valueKeys.size && key != headTail) {
        nearStableValueList(headTail) = nearStableValueList(key)
        nearStableValueList.remove(key)
      }
    }
    nearStableValueList.toList
  }

  def top3NearStable(peak: Boolean, weekMax: Float, minPeriod: String, min: Float, coefficientMap: mutable.LinkedHashMap[String, (Float, Seq[Float])], valueKeys: Seq[Int], coefficientLimit: Float, condition: String, valueLimit: Float, minSize: Int): Seq[String] = {
    val cn = if (peak) "波峰" else "波谷"
    val row = mutable.ListBuffer[String]()
    // 按小时数排倒序，取前三
    val tmpNearStableValueList = if (peak) nearStablePeak(coefficientMap, valueKeys, coefficientLimit, condition, valueLimit, minSize) else nearStableTrough(coefficientMap, valueKeys, coefficientLimit, condition, valueLimit, minSize)
    val finalNearStableValueList = tmpNearStableValueList.map(kv => {
      val (key, children) = kv
      val childMean = children.sum / children.length
      val coefficient = (children.max - min) / (weekMax - min)
      (key, (childMean, children.max, coefficient, children))
    })

    if (logger.isDebugEnabled) {
      logger.debug(s"${cn}附近大致平稳周期")
      finalNearStableValueList.foreach(kv => {
        val (key, (childMean, childMax, coefficient, children)) = kv
        logger.debug(s"[$key]:[$childMean]:[$childMax]:[$coefficient]:[${children.mkString(",")}]")
      })
    }

    finalNearStableValueList.slice(0, 3).foreach(kv => {
      val (key, (childMean, childMax, coefficient, _)) = kv
      row.append(s"'$key'")
      row.append(childMean.toString)
      row.append(childMax.toString)
      row.append(coefficient.toString)
    })
    1.to(3 - finalNearStableValueList.length).foreach(_ => 1.to(4).foreach(_ => row.append(null)))

    val periodKeys = periodToList(minPeriod)
    val containPeriodNearStableValueList = finalNearStableValueList.filter(kv => {
      val nearStableKeys = periodToList(kv._1)
      periodKeys.count(nearStableKeys.contains(_)) == periodKeys.length
    })

    if (containPeriodNearStableValueList.nonEmpty) {
      logger.debug(s"大致平稳周期-包含${cn}的周期")
      containPeriodNearStableValueList.sortWith((x, y) => x._2._4.size > y._2._4.size).slice(0, 1).foreach(kv => {
        val (key, (childMean, childMax, coefficient, children)) = kv
        logger.debug(s"[$key]:[$childMean]:[$childMax]:[$coefficient]:[${children.mkString(",")}]")

        row.append(s"'$key'")
        row.append(childMean.toString)
        row.append(childMax.toString)
        row.append(coefficient.toString)
      })
    } else {
      1.to(4).foreach(_ => row.append(null))
    }

    row
  }

  /**
    * 找核心周期
    */
  @Deprecated
  def calculateCore(values: Seq[Float], valueKeys: Seq[Int]): String = {
    if (values.length <= 2) {
      ""
    } else {
      val sorted = increaseOrDecrease(values)
      if (sorted) {
        fmt2Bit(valueKeys(valueKeys.length / 2 + 1))
      } else {
        val troughMin = values.min
        val troughMinIndex = values.indexWhere(_ == troughMin)
        var troughCore = ""
        if (troughMinIndex >= values.length / 2) {
          // 最左向最低点移
          var i = 0
          breakable {
            while (i <= troughMinIndex - 2) {
              val subValues = values.slice(i, troughMinIndex + 1)
              val sorted = increaseOrDecrease(subValues)
              if (sorted) {
                // 递增,递减
                val troughCoreIndex = values.indexWhere(_ == subValues(subValues.length / 2))
                // logger.info(s"$troughCoreIndex")
                // logger.info(s"${valueKeys.mkString(",")}")
                troughCore = fmt2Bit(valueKeys(troughCoreIndex))
                break
              }
              i = i + 1
            }
          }

          // 最低点向最左移
          if (troughCore == "") {
            breakable {
              i = troughMinIndex
              while (i >= 3) {
                val subValues = values.slice(0, i)
                val sorted = increaseOrDecrease(subValues)
                if (sorted) {
                  // 递增,递减
                  val troughCoreIndex = values.indexWhere(_ == subValues(subValues.length / 2))
                  troughCore = fmt2Bit(valueKeys(troughCoreIndex))
                  break
                }
                i = i - 1
              }
            }
          }
        }

        if (troughCore == "") {
          // 最右向最低点移
          var j = values.length
          breakable {
            while (j >= troughMinIndex + 3) {
              val subValues = values.slice(troughMinIndex, j)
              val sorted = increaseOrDecrease(subValues)
              if (sorted) {
                // 递增,递减
                val troughCoreIndex = values.indexWhere(_ == subValues(subValues.length / 2))
                troughCore = fmt2Bit(valueKeys(troughCoreIndex))
                break
              }
              j = j - 1
            }
          }
        }

        if (troughCore == "") {
          // 最低点向最右侈
          var j = troughMinIndex
          breakable {
            while (j <= values.length - 3) {
              val subValues = values.slice(j, values.length)
              val sorted = increaseOrDecrease(subValues)
              if (sorted) {
                // 递增,递减
                val troughCoreIndex = values.indexWhere(_ == subValues(subValues.length / 2))
                troughCore = fmt2Bit(valueKeys(troughCoreIndex))
                break
              }
              j = j + 1
            }
          }
        }

        troughCore
      }
    }
  }

  def periodToList(period: String, head: Int = 0, tail: Int = 23): Seq[Int] = {
    if (period == null || period.isEmpty) {
      List.empty[Int]
    } else {
      val childHead = period.split(":").head.toInt
      val childTail = period.split(":").last.toInt
      if (childHead <= childTail) {
        childHead.to(childTail)
      } else {
        childHead.to(tail) ++ head.to(childTail)
      }
    }
  }

  def isInteger(str: String): Boolean = {
    if (str == null || str.isEmpty)
      false
    else {
      val number = "[0-9]+".r
      try {
        number.findFirstIn(str).get.length == str.length
      } catch {
        case _: Exception => false
      }
    }
  }

  def fmt2Bit(number: Int): String = if (number < 10) s"0$number" else s"$number"

  def dayOfWeek(calendar: Calendar): Int = if (calendar.get(Calendar.DAY_OF_WEEK) == 1) 7 else calendar.get(Calendar.DAY_OF_WEEK) - 1

  def dayOfWeek(date: Date): Int = {
    val calendar = Calendar.getInstance()
    calendar.setTime(date)
    dayOfWeek(calendar)
  }

  def dayOfWeek(date: String): Int = {
    dayOfWeek(dateFmt.parse(date))
  }

  def humanReadblePeriods(periods:Seq[String]): String = {
    periods.map(humanReadblePeriods(_)).mkString(",")
  }

  def humanReadblePeriods(period:String, head: Int = 0, tail: Int = 23): String = {
    if (period == null || period.isEmpty) {
      ""
    } else {
      val childHead = period.split(":").head.toInt
      val childTail = period.split(":").last.toInt
      if (childHead <= childTail) {
        val hourList = childHead.to(childTail)
        fmt2Bit(hourList.head) + hourDelimiter + fmt2Bit(hourList.last)
      } else {
        val headHourList = head.to(childTail)
        val tailHourList = childHead.to(tail)
        fmt2Bit(headHourList.head) + hourDelimiter + fmt2Bit(headHourList.last) + "," + fmt2Bit(tailHourList.head) + hourDelimiter + fmt2Bit(tailHourList.last)
      }
    }
  }


  def lowPeriod(values: Seq[Float]): Seq[String] = {
    val row = mutable.ListBuffer[String]()
    1.to(8).foreach(i => {
      row.append(splitLowValues(i, values).filter(_._2 == 1).keys.map(valueKeys => {
        s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}"
      }).mkString(","))
    })
    row
  }

  def splitLowValues(flag: Int, values: Seq[Float]): mutable.LinkedHashMap[Seq[Int], Int] = {
    val flagList = 0.to(23).map(i => {
      val x = values(i)
      if ((flag == 1 && 0f < x && x <= 0.025f) ||
        (flag == 2 && 0f < x && x <= 0.05f) ||
        (flag == 3 && 0f < x && x <= 0.075f) ||
        (flag == 4 && 0f < x && x <= 0.1f) ||
        (flag == 5 && 0f < x && x <= 0.15f) ||
        (flag == 6 && 0f < x && x <= 0.2f) ||
        (flag == 7 && 0f < x && x <= 0.3f) ||
        (flag == 8 && 0.3f < x)) {
        1
      } else {
        0
      }
    })
    gatherContinueFlagsCircle(0.to(23), flagList)
  }

  def zeroLessActuser(values: Seq[Float], valueKeys: Seq[Int], coefficientMap: Map[Int, (Float, Seq[Float], Seq[Int])], lessLimit: Float = 3): Seq[String] = {
    val headTail = s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}"
    val min = values.filter(_ > -1).min
    val row = mutable.ListBuffer[String]()
    // 零值时段
    if (min > 0)
      row.append("")
    else if (values.count(_ == 0) == values.length)
      row.append(headTail)
    else if (values.count(_ == 0) == 1)
      row.append(fmt2Bit(valueKeys(values.indexWhere(_ == 0))))
    else {
      // 如果波谷=零值，则取波谷
      val flagList = mutable.ListBuffer[Int]()
      valueKeys.indices.foreach(i => {
        if (values(i) == 0)
          flagList.append(1)
        else
          flagList.append(0)
      })
      val continueFlags = gatherContinueFlagsCircle(valueKeys, flagList).filter(_._2 == 1)
      if (continueFlags.nonEmpty) {
        val sortedContinueFlags = continueFlags.toList.sortWith((x, y) => x._1.size > y._1.size)
        var troughContainZero = false
        if (coefficientMap != null && coefficientMap.nonEmpty) {
          val coefficientTemp = coefficientMap.minBy(_._2._1)._2._1
          val coefficientMin = coefficientMap.filter(_._2._1 == coefficientTemp).maxBy(_._2._2.size)
          // val coefficientMin = coefficientMap.minBy(_._2._1)
          val troughKeys = coefficientMin._2._3

          val troughContainZeroContinue = sortedContinueFlags.filter(kv => {
            troughKeys.count(kv._1.contains(_)) == troughKeys.length
          })

          if (troughContainZeroContinue.nonEmpty) {
            row.append(s"${fmt2Bit(troughKeys.head)}:${fmt2Bit(troughKeys.last)}")
            troughContainZero = true
          }
        }
        if (!troughContainZero) {
          val keys = sortedContinueFlags.head._1
          row.append(s"${fmt2Bit(keys.head)}:${fmt2Bit(keys.last)}")
        }
      } else {
        row.append("")
      }
    }
    // 少用户时段
    if (min > lessLimit) {
      row.append("")
    } else {
      val flagList = mutable.ListBuffer[Int]()
      valueKeys.indices.foreach(i => {
        if (0 < values(i) && values(i) <= lessLimit)
          flagList.append(1)
        else
          flagList.append(0)
      })
      val continueFlags = gatherContinueFlagsCircle(valueKeys, flagList).filter(_._2 == 1).toList.sortWith((x, y) => x._1.size > y._1.size)
      if (continueFlags.nonEmpty) {
        val keys = continueFlags.head._1
        row.append(s"${fmt2Bit(keys.head)}:${fmt2Bit(keys.last)}")
      }
      else
        row.append("")
    }
    row
  }

  def calculateHourList(periods: Seq[String], size: Int): Seq[Int] = {
    if (periods.nonEmpty) {
      val delta = size * 0.8f
      periods.flatMap(period => {
        periodToList(period)
      }).groupBy(x => x).mapValues(_.length).filter(_._2 > delta).toList.sortBy(_._1).map(_._1)
    } else {
      List()
    }
  }

  def gather(hourList: Seq[Int]): String = {
    if (hourList.isEmpty) {
      "0"
    } else {
      if (hourList.size == 2) {
        if (hourList.last - hourList.head == 1) {
          s"${fmt2Bit(hourList.head)}:${fmt2Bit(hourList.last)}"
        } else {
          s"${fmt2Bit(hourList.head)}:${fmt2Bit(hourList.head)}"
        }
      } else {
        val flagList = 0.to(23).map(i => {
          if (hourList.contains(i))
            1
          else
            0
        })
        // 选连续最长的
        val continueMap = gatherContinueFlagsCircle(0.to(23), flagList).filter(_._2 == 1)
        val valueKeys = continueMap.toList.maxBy(_._1.size)._1
        s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}"
      }
    }
  }

  def existsPartition(statement: Statement, table: String, partition: String): Boolean = {
    val sql = s"SELECT PARTITION_NAME FROM information_schema.partitions WHERE table_name ='$table' AND PARTITION_NAME = '$partition'"
    val rs = statement.executeQuery(sql)
    if (rs.next())
      true
    else
      false
  }

  def loadYearDataFromMysql(statement: Statement, table: String, fields: Seq[(String, String)]): mutable.HashMap[(String, String), mutable.Map[String, String]] = {
    val values = mutable.HashMap[(String, String), mutable.Map[String, String]]()
    val rs = statement.executeQuery(s"SELECT * FROM `$table`")
    while (rs.next()) {
      val row = mutable.HashMap[String, String]()
      fields.indices.foreach(i => {
        val columnName = fields(i)._1.replaceAll("`", "")
        val columnType = fields(i)._2
        if (columnType.startsWith("int") || columnType.startsWith("TINYINT")) {
          row(columnName) = rs.getInt(i + 1).toString
        } else if (columnType.startsWith("float")) {
          row(columnName) = rs.getFloat(i + 1).toString
        } else {
          row(columnName) = rs.getString(i + 1)
        }
      })
      values((rs.getInt(2).toString, rs.getInt(4).toString)) = row
    }
    rs.close()
    values
  }

  def loadSomData(spark: SparkSession, table: String, province: Int, day: Int): Map[(String, String), Seq[String]] = {
    val sql = s"SELECT `base_statn_id`, `cell_id`, `merge_after_is_pure`, `is_festival`, `silhouette_score`, `corr_score`, `c9`, `c10`, `c11`, `c12` FROM $table where province_id = $province and day = $day"
    val df = spark.sql(sql)
    val encoder = Encoders.tuple(Encoders.tuple(Encoders.STRING, Encoders.STRING), RowEncoder(df.schema))
    df.map(row => ((row.getString(0), row.getString(1)), row))(encoder).collect().toMap.mapValues(row => {
      List(
        row.getString(2),
        row.getString(3),
        row.getString(4),
        row.getString(5),
        row.getString(6),
        row.getString(7),
        row.getString(8),
        row.getString(9)
      )
    })
  }
}
