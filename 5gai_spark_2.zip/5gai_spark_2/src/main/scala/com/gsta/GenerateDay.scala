package com.gsta

import java.util.Calendar

import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

import scala.collection.mutable

object GenerateDay extends Util with Serializable {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    val kpiTable = args(0).split(":").head
    val kpiField = args(0).split(":")(1)
    val fieldType = args(0).split(":").last.toLowerCase()
    val weekTable = args(1).split(":").head
    val minMaxColumnPrefix = args(1).split(":").last
    val db = weekTable.split("\\.").head
    val coefficientLimit = args(2).toFloat
    val condition = args(3)
    val delta = args(4).toFloat
    val energySavingMinSize = args(5).toInt
    val savePath = args(6)
    val numPartitions = args(7).toInt
    val regionListConfig = if (args.length == 9) args.last.split(",").map(_.toInt) else Array.empty[Int]

    val directList = savePath.split("/")
    val day = directList.last
    val province = directList(directList.length - 2).toInt

    val calendar = Calendar.getInstance()
    calendar.setTime(dateFmt.parse(day))

    val day_of_week = dayOfWeek(calendar)

    val dateHourList = mutable.ListBuffer[Long]()
    calendar.add(Calendar.HOUR, -1)
    1.to(24 + 2).foreach(_ => {
      dateHourList.append(dateHourFmt.format(calendar.getTime).toLong)
      calendar.add(Calendar.HOUR, 1)
    })
    val targetHourList = dateHourList.slice(1, dateHourList.length - 1)

    calendar.add(Calendar.DATE, -(day_of_week + 7))
    val lastWeekPartition = dateFmt.format(calendar.getTime)

    calendar.add(Calendar.DATE, -7)
    val lastTweekPartition = dateFmt.format(calendar.getTime)

    val spark = SparkSession.builder().appName("5GAI-generate-day-data").enableHiveSupport().getOrCreate()
    val sc = spark.sparkContext

    val rows = mutable.ListBuffer[String]()

    val valueKeys = 0.to(23)
    val weekMinMaxData = generateWeekMinMaxData(spark, weekTable, minMaxColumnPrefix, province, lastWeekPartition.toInt)
    val tweekMinMaxData = generateWeekMinMaxData(spark, weekTable, minMaxColumnPrefix, province, lastTweekPartition.toInt)
    val regionList = generateRegionList(spark, kpiTable, province, dateHourList.head.toString.substring(0, 8).toInt, dateHourList.last.toString.substring(0, 8).toInt)

    val targetRegionList = if (regionListConfig.isEmpty || !regionList.exists(x => regionListConfig.contains(x._1)))
      regionList
    else
      regionList.filter(x => regionListConfig.contains(x._1))

    logger.info(s"region list:[${targetRegionList.map(x => s"${x._1}->${x._2}").mkString(",")}]")

    for (region <- targetRegionList.map(_._1)) {
      val lastCount = rows.length
      val kpiData = generateKpiData(spark, kpiTable, kpiField, province, region, dateHourList)
      kpiData.foreach(kv => {
        val dateHourDataMap =
          if (fieldType == "long")
            kv._2.map(row => (row.getLong(4), row.getLong(5).toFloat)).toMap
          else if (fieldType == "double")
            kv._2.map(row => (row.getLong(4), row.getDouble(5).toFloat)).toMap
          else
            kv._2.map(row => (row.getLong(4), row.getFloat(5))).toMap

        val fillValues = mutable.ListBuffer[Float]()
        valueKeys.foreach(i => {
          val dateHour = targetHourList(i)
          if (dateHourDataMap.contains(dateHour)) {
            fillValues.append(dateHourDataMap(dateHour))
          } else {
            // 补值
            // 前后一小时均值
            val j = i + 1
            val mean = if (dateHourDataMap.contains(dateHourList(j - 1)) && dateHourDataMap.contains(dateHourList(j + 1))) {
              (dateHourDataMap(dateHourList(j - 1)) + dateHourDataMap(dateHourList(j + 1))) / 2
            } else {
              -1
            }

            fillValues.append(mean)
          }
        })
        val realValues = fillValues.filter(_ > -1)
        if (realValues.nonEmpty) {
          // 静态属性
          val row = generateSectorInfoFromKpi(kv._2.head)

          // 前两周数据(非填充)
          // 原始数据
          targetHourList.foreach(dateHour => {
            if (dateHourDataMap.contains(dateHour)) {
              row.append(dateHourDataMap(dateHour).toString)
            } else {
              row.append("")
            }
          })

          val fullFlag = row.slice(row.length - valueKeys.length, row.length).count(x => x.nonEmpty)
          val fillFullFlag = realValues.length

          fillValues.foreach(x => if (x > -1) row.append(x.toString) else row.append(""))
          row.append(fullFlag.toString)
          row.append(fillFullFlag.toString)
          row.appendAll(baseCoefficient(fillValues, valueKeys))
          // 4 dwprb
          if (delta < 1) {
            // low1 ~ low8
            // dwprb
            row.appendAll(lowPeriod(fillValues))
          }
          val (firstWmin, firstWmax) = if (weekMinMaxData.contains(kv._1)) weekMinMaxData(kv._1) else (-1f, -1f)
          val (secondWmin, secondWmax) = if (tweekMinMaxData.contains(kv._1)) tweekMinMaxData(kv._1) else (-1f, -1f)
          val minList = List(firstWmin, secondWmin)
          val maxList = List(firstWmax, secondWmax)
          val wmin = if (minList.count(_ == -1) == minList.length) -1 else minList.filterNot(_ == -1).min
          val wmax = if (maxList.count(_ == -1) == maxList.length) -1 else maxList.filterNot(_ == -1).max
          if (wmin >= 0 && wmax >= 0 && wmax != realValues.min) {
            val coefficientMap = splitValuesPro(wmax, fillValues, valueKeys, energySavingMinSize)
            val legacyCoefficientMap = coefficientMap.map(kv => {
              val valueKeys = kv._2._3
              (s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}", (kv._2._1, kv._2._2))
            })
            if (delta >= 1) {
              // maxact
              row.appendAll(zeroLessActuser(fillValues, valueKeys, coefficientMap.toMap))
            }

            if (fillValues.length > realValues.length) {
              1.to(valueKeys.length + 26).foreach(_ => row.append(""))
            } else {
              row.appendAll(coefficientScore(coefficientMap))
              // 波峰
              val (_, coefficientPeakList) = coefficientPeak(coefficientMap)
              row.appendAll(coefficientPeakList)
              // 波谷
              val (minPeriod, coefficientTroughList) = coefficientTrough(coefficientMap)
              row.appendAll(coefficientTroughList)

              val min = realValues.min
              val valueLimit = if (delta < 1) math.min(min + (wmax - wmin) * delta, 0.1f) else delta
              row.appendAll(top3NearStable(peak = false, wmax, minPeriod, min, legacyCoefficientMap, valueKeys, coefficientLimit, condition, valueLimit, energySavingMinSize))
            }
          } else {
            if (delta >= 1) {
              // maxact
              row.appendAll(zeroLessActuser(fillValues, valueKeys, null))
            }
            85.to(134).foreach(_ => row.append(""))
          }
          row.append(day_of_week.toString)
          rows.append(row.mkString("|").replaceAll("'", "").replaceAll("null", ""))
        }
      })
      logger.info(s"$province $region $day generates ${rows.length - lastCount} rows $kpiField data")
    }

    val hdfsPath = (directList.slice(0, directList.length - 2) ++ Array(province, day)).mkString("/")
    val fs = FileSystem.get(sc.hadoopConfiguration)
    if (fs.exists(new Path(hdfsPath)))
      fs.delete(new Path(hdfsPath), true)

    sc.hadoopConfiguration.set("mapred.output.compress", "false")
    sc.parallelize(rows).repartition(numPartitions).saveAsTextFile(hdfsPath)

    spark.sql("set hive.exec.dynamic.partition=true")
    spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
    spark.sql(s"alter table $db.${directList(directList.length - 3)} add IF NOT EXISTS partition(province_id=$province, day=$day) location '$province/$day/'")

    logger.info(s"$province $day generates ${rows.length} rows $kpiField data")

    spark.stop()
  }
}
