package com.gsta

import org.apache.spark.SparkContext
import org.slf4j.LoggerFactory

import scala.collection.mutable.ListBuffer

object WordCount {
  private val logger = LoggerFactory.getLogger(this.getClass)
  def main(args: Array[String]): Unit = {
    val lines = ListBuffer[String]()
    val sc = new SparkContext()
    sc.textFile(args(0)).flatMap(line => line.split("\\W+").filterNot(_.isEmpty)).map(w => (w, 1)).reduceByKey((x, y) => x + y).collect().foreach(wc => lines.append(s"${wc._1},${wc._2}"))

    sc.parallelize(lines, 1).saveAsTextFile(args(1))

    val endTime = System.currentTimeMillis() / 1000
    val consume = endTime - sc.startTime / 1000
    logger.info(s"[consume ${consume * 1000} ms]")
    sc.stop()
  }
}
