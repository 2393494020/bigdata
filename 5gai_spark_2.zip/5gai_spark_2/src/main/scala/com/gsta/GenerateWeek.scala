package com.gsta

import java.util.Calendar

import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.{Encoders, SparkSession}
import org.slf4j.LoggerFactory

import scala.collection.mutable

object GenerateWeek extends Util with Serializable {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    val db = args(0).split("\\.").head
    val dayTable = args(0).split(":").head
    val columnPrefix = args(0).split(":").last
    val savePath = args(1)
    val numPartitions = args(2).toInt

    val directList = savePath.split("/")
    val day = directList.last
    val province = directList(directList.length - 2).toInt

    val calendar = Calendar.getInstance()
    calendar.setTime(dateFmt.parse(day))

    calendar.add(Calendar.DATE, -dayOfWeek(calendar))
    val sunday = dateFmt.format(calendar.getTime)

    calendar.add(Calendar.DATE, -6)
    val monday = dateFmt.format(calendar.getTime)

    val spark = SparkSession.builder().appName("5GAI-generate-week-data").enableHiveSupport().getOrCreate()
    val sc = spark.sparkContext
    val sql = s"select city_id, base_statn_id, base_statn_name, cell_id, cell_name, bs_vendor, is_indoor, band, network, region, cover_hotspot_type, nb_flag, band_width, ${columnPrefix}min, ${columnPrefix}max, ${columnPrefix}idxmax, ${columnPrefix}idxmin, day_of_week from $dayTable where province_id = $province and day >= $monday and day <= $sunday"
    val df = spark.sql(sql)
    val encoder = Encoders.tuple(Encoders.tuple(Encoders.scalaInt, Encoders.scalaInt), RowEncoder(df.schema))
    val data = df.map(row => ((row.getInt(1), row.getInt(3)), row))(encoder).collect().groupBy(_._1).mapValues(x => x.map(_._2))
    val rows = mutable.ListBuffer[String]()
    data.foreach(kv => {
      val row = generateDimSectorInfoFromDay(kv._2.head)

      val values = kv._2.flatMap(dataRow => List(dataRow.getFloat(13), dataRow.getFloat(14)))
      val subDataMap = kv._2.map(dataRow => (dataRow.getInt(17), List(dataRow.getFloat(13).toString, dataRow.getFloat(14).toString, dataRow.getString(15), dataRow.getString(16)))).toMap
      row.append(values.min.toString)
      row.append(values.max.toString)
      1.to(7).foreach(day => {
        if (subDataMap.contains(day)) {
          row.appendAll(subDataMap(day))
        } else {
          row.appendAll(List("", "", "", ""))
        }
      })
      rows.append(row.mkString("|").replaceAll("'", "").replaceAll("null", ""))
    })

    val hdfsPath = (directList.slice(0, directList.length - 2) ++ Array(province, monday)).mkString("/")
    val fs = FileSystem.get(sc.hadoopConfiguration)
    if (fs.exists(new Path(hdfsPath)))
      fs.delete(new Path(hdfsPath), true)

    sc.hadoopConfiguration.set("mapred.output.compress", "false")
    sc.parallelize(rows).repartition(numPartitions).saveAsTextFile(hdfsPath)

    spark.sql("set hive.exec.dynamic.partition=true")
    spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
    spark.sql(s"alter table $db.${directList(directList.length - 3)} add IF NOT EXISTS partition(province_id=$province, day=$monday) location '$province/$monday/'")

    logger.info(s"$province $monday-$sunday generates ${rows.length} rows $columnPrefix data")

    spark.stop()
  }
}
