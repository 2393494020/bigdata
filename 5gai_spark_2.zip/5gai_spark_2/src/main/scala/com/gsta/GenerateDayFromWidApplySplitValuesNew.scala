package com.gsta

import java.util.Calendar

import com.gsta.GenerateDay.{dayOfWeek, lowPeriod}
import org.slf4j.LoggerFactory

import scala.collection.mutable
import scala.io.Source

object GenerateDayFromWidApplySplitValuesNew extends Util with Serializable {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def main0(args: Array[String]): Unit = {
    val valueLine = "0.0162,0.0334,6.0E-4,7.0E-4,0.0144,0.0255,0.0211,0.0262,0.0294,0.0148,0.0315,0.1125,0.0346,0.0878,0.0614,0.0905,0.0167,0.025,0.0303,0.0639,0.0932,0.1834,0.1064,0.085099995"
    val tweekvalueLine = "0.1584,0.1389,0.0255,0.0224,0.0139,0.024,0.0265,0.0576,0.0123,0.0231,0.0434,0.0805,0.0254,0.1027,0.1213,0.1034,0.0724,0.0481,0.0394,0.0408,0.0653,0.1423,0.0681,0.1136,0.2985,0.3615,0.3682,0.1957,0.0809,0.222,0.103,0.0422,0.1658,0.3836,0.4263,0.4574,0.7255,0.3328,0.1948,0.1608,0.0775,0.057,0.1403,0.132,0.16,0.0776,0.0163,0.0133,9.0E-4,4.0E-4,0.0017,0.0015,0.0077,0.0453,0.073,0.0331,0.0465,0.0698,0.0581,0.1,0.0781,0.1937,0.0758,0.0984,0.0646,0.1173,0.0576,0.0251,0.0691,0.0528,0.008,9.0E-4,0.0692,0.1256,0.1688,0.0753,0.1252,0.1402,0.223,0.3937,0.229,0.1093,0.202,0.0565,0.0922,0.0483,0.0371,0.0611,0.0514,0.1326,0.1356,0.0544,0.0907,0.0583,0.0716,0.0403,0.0307,0.016,0.0258,0.1252,0.0552,0.0525,0.0767,0.053,0.1102,0.1484,0.1805,0.1087,0.1394,0.1314,0.0695,0.1078,0.2157,0.1889,0.1171,0.0805,0.0294,0.0205,0.0737,0.1305,0.0388,0.0403,0.0265,0.07,0.1285,0.1042,0.051,0.0441,0.0922,0.1212,0.0794,0.0542,0.0428,0.0858,0.1193,0.1174,0.1459,0.188,0.0943,0.0459,0.0349,0.0456,0.0348,0.0367,0.0155,0.0654,0.085,0.0458,0.0453,0.0347,0.0583,0.0971,0.052,0.0648,0.0727,0.0985,0.058,0.0943,0.1068,0.14,0.0954,0.018,0.0267,0.0086,0.0452,0.0259,7.0E-4,0.0017,0.0698,0.0504,0.0327,0.04,0.0399,0.0298,0.0055,0.074,0.1008,0.0517,0.0409,0.0194,0.0485,0.169,0.0963,0.1886,0.0321,0.0094,0.0027,3.0E-4,0.0013,0.0113,0.0495,0.1052,0.082,0.1184,0.0889,0.0594,0.0695,0.0739,0.1298,0.5349,0.0421,0.1029,0.1271,0.0929,0.1779,0.0832,0.1704,0.2263,0.0364,0.0352,0.0047,0.0022,0.0488,0.0476,0.1424,0.149,0.0946,0.0646,0.0496,0.0927,0.0421,0.033,0.0653,0.0421,0.0047,0.0431,0.0608,0.1366,0.0558,0.0274,0.0147,0.0036,0.001,4.0E-4,0.0061,0.0189,0.0151,0.022,0.0451,0.1103,0.075,0.0504,0.134,0.0414,0.0584,0.1003,0.0428,0.0116,0.1008,0.07,0.1237,0.0588,0.0753,0.0336,0.0253,0.0016,5.0E-4,5.0E-4,0.0096,0.06,0.0402,0.0735,0.0672,0.0733,0.0728,0.064,0.1234,0.1349,0.104,0.0351,0.05,0.0193,0.0233,0.0847,0.0287,0.0395,0.0012,4.0E-4,0.0014,3.0E-4,3.0E-4,0.0021,0.0362,0.0888,0.0773,0.0753,0.0253,0.0685,0.0843,0.0893,0.0809,0.1167,0.066,0.0329,0.0843,0.1438,0.0714,0.1176,0.0425,0.0132,0.0719,0.0014,8.0E-4,8.0E-4,0.0164,0.0405,0.0573,0.0532,0.083,0.0922,0.0441,0.0436,0.0538,0.1118,0.0724,0.0639,0.0998,0.0779,0.0892,0.1309,0.0906"
    val fillValues = valueLine.split(",").map(_.toFloat)
    val tweekValues = tweekvalueLine.split(",").map(_.toFloat)
    val valueKeys = 0.to(23)

    val coefficientMap = splitValuesPro(tweekValues.max, fillValues, valueKeys, 3)
    val legacyCoefficientMap = coefficientMap.map(kv => {
      val valueKeys = kv._2._3
      (s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}", (kv._2._1, kv._2._2))
    })

    val row = mutable.ListBuffer[String]()
    row.appendAll(coefficientScore(coefficientMap))
    println(row.length)
    println(row.mkString("|").replaceAll("'", "").replaceAll("null", ""))
  }

  def main1(args: Array[String]): Unit = {
    val coefficientLimit = 0.1f
    val condition = "value"
    val delta = 0.2f
    val minSize = 3
    val valueKeys = 0.to(23)

    val dataFile = Source.fromFile("/home/iss/Downloads/gsta/5gai_spark_2/day")
    val dataLines = dataFile.getLines().toList
    0.until(dataLines.length / 2).foreach(i => {
      val lines = dataLines.slice(i * 2, (i + 1) * 2)
      val wvalues = lines.head.split("\\s+").map(_.toFloat)
      val values = lines.last.split("\\s+").map(_.toFloat)
      val coefficientMap = splitValuesPro(wvalues.max, values, 0.to(23), minSize)

      // 波峰
      val (_, coefficientPeakList) = coefficientPeak(coefficientMap)
      // 波谷
      val (minPeriod, coefficientTroughList) = coefficientTrough(coefficientMap)

      val min = values.min
      val valueLimit = if (delta < 1) math.min(min + (wvalues.max - wvalues.min) * delta, 0.1f) else delta
      top3NearStable(peak = false, wvalues.max, minPeriod, min, coefficientMap.map(kv => {
        val valueKeys = kv._2._3
        (s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}", (kv._2._1, kv._2._2))
      }), valueKeys, coefficientLimit, condition, valueLimit, minSize)
    })
    dataFile.close()
  }

  def main11(args: Array[String]): Unit = {
    val coefficientLimit = 0.1f
    val condition = "value"
    val delta = 0.2f
    val minSize = 3
    val valueKeys = 0.to(23)

    val calendar = Calendar.getInstance()
    calendar.setTime(dateHourFmt.parse("2020033000"))

    val t1Values = mutable.LinkedHashMap[String, Float]()
    1.to(24 * 2 * 7).foreach(_ => {
      t1Values(dateHourFmt.format(calendar.getTime)) = -1
      calendar.add(Calendar.HOUR, 1)
    })

    val d1Values = mutable.LinkedHashMap[String, Float]()
    calendar.setTime(dateHourFmt.parse("2020041723"))
    1.to(24 + 2).foreach(_ => {
      d1Values(dateHourFmt.format(calendar.getTime)) = -1
      calendar.add(Calendar.HOUR, 1)
    })

    val t2Values = mutable.LinkedHashMap[String, Float]()
    calendar.setTime(dateHourFmt.parse("2020040600"))
    1.to(24 * 2 * 7).foreach(_ => {
      t2Values(dateHourFmt.format(calendar.getTime)) = -1
      calendar.add(Calendar.HOUR, 1)
    })

    val d2Values = mutable.LinkedHashMap[String, Float]()
    calendar.setTime(dateHourFmt.parse("2020041923"))
    1.to(24 + 2).foreach(_ => {
      d2Values(dateHourFmt.format(calendar.getTime)) = -1
      calendar.add(Calendar.HOUR, 1)
    })

    /*val values = mutable.LinkedHashMap[String, Float]()
    calendar.setTime(dateHourFmt.parse("2020033000"))
    1.to(24 * 7 * 3 + 24).foreach(_ => {
      values(dateHourFmt.format(calendar.getTime)) = -1
      calendar.add(Calendar.HOUR, 1)
    })*/

    val dataFile = Source.fromFile("/home/iss/Downloads/gsta/5gai_spark_2/856282_6.txt")
    dataFile.getLines().foreach(line => {
      val segments = line.trim.split("\\s+")
      if (t1Values.contains(segments.head))
        t1Values(segments.head) = segments.last.toFloat

      if (t2Values.contains(segments.head))
        t2Values(segments.head) = segments.last.toFloat

      if (d1Values.contains(segments.head))
        d1Values(segments.head) = segments.last.toFloat

      if (d2Values.contains(segments.head))
        d2Values(segments.head) = segments.last.toFloat
    })
    dataFile.close()

    println(t1Values.mkString(","))
    println(d1Values.mkString(","))
    println(t2Values.mkString(","))
    println(d2Values.mkString(","))

    if (d1Values.slice(1, 25).count(_._2 == -1) == 0) {
      val wvalues = t1Values.values.filter(_ >= 0)
      val values = d1Values.values.toList.slice(1, 25)

      logger.debug(s"前两周极值:[${wvalues.max}, ${wvalues.min}]")

      val coefficientMap = splitValuesPro(wvalues.max, values, 0.to(23), minSize)

      // 波峰
      val (_, coefficientPeakList) = coefficientPeak(coefficientMap)
      // 波谷
      val (minPeriod, coefficientTroughList) = coefficientTrough(coefficientMap)

      val min = values.min
      val valueLimit = if (delta < 1) math.min(min + (wvalues.max - wvalues.min) * delta, 0.1f) else delta
      top3NearStable(peak = false, wvalues.max, minPeriod, min, coefficientMap.map(kv => {
        val valueKeys = kv._2._3
        (s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}", (kv._2._1, kv._2._2))
      }), valueKeys, coefficientLimit, condition, valueLimit, minSize)
    }

    if (d2Values.slice(1, 25).count(_._2 == -1) == 0) {
      val wvalues = t2Values.values.filter(_ >= 0)
      val values = d2Values.values.toList.slice(1, 25)

      logger.debug(s"前两周极值:[${wvalues.max}, ${wvalues.min}]")

      val coefficientMap = splitValuesPro(wvalues.max, values, 0.to(23), minSize)

      // 波峰
      val (_, coefficientPeakList) = coefficientPeak(coefficientMap)
      // 波谷
      val (minPeriod, coefficientTroughList) = coefficientTrough(coefficientMap)

      val min = values.min
      val valueLimit = if (delta < 1) math.min(min + (wvalues.max - wvalues.min) * delta, 0.1f) else delta
      top3NearStable(peak = false, wvalues.max, minPeriod, min, coefficientMap.map(kv => {
        val valueKeys = kv._2._3
        (s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}", (kv._2._1, kv._2._2))
      }), valueKeys, coefficientLimit, condition, valueLimit, minSize)
    }
  }

  def main(args: Array[String]): Unit = {
    val coefficientLimit = 0.1f
    val condition = "value"
    val delta = 0.2f
    val minSize = 3
    val valueKeys = 0.to(23)

    val calendar = Calendar.getInstance()
    calendar.setTime(dateHourFmt.parse("2020033000"))

    val t1Values = mutable.LinkedHashMap[String, Float]()
    1.to(24 * 7).foreach(_ => {
      t1Values(dateHourFmt.format(calendar.getTime)) = -1
      calendar.add(Calendar.HOUR, 1)
    })

    val d1Values = mutable.LinkedHashMap[String, Float]()
    calendar.setTime(dateHourFmt.parse("2020040823"))
    1.to(24 + 2).foreach(_ => {
      d1Values(dateHourFmt.format(calendar.getTime)) = -1
      calendar.add(Calendar.HOUR, 1)
    })

    val dataFile = Source.fromFile("/home/iss/Downloads/gsta/5gai_spark_2/486286_50.txt")
    dataFile.getLines().foreach(line => {
      val segments = line.trim.split("\\s+")
      if (t1Values.contains(segments.head))
        t1Values(segments.head) = segments.last.toFloat

      if (d1Values.contains(segments.head))
        d1Values(segments.head) = segments.last.toFloat
    })
    dataFile.close()

    println(t1Values.mkString(","))
    println(d1Values.mkString(","))

    if (d1Values.slice(1, 25).count(_._2 == -1) == 0) {
      val wvalues = t1Values.values.filter(_ >= 0)
      val values = d1Values.values.toList.slice(1, 25)

      logger.debug(s"周极值:[${wvalues.max}, ${wvalues.min}]")

      val coefficientMap = splitValuesPro(wvalues.max, values, 0.to(23), minSize)

      // 波峰
      val (_, coefficientPeakList) = coefficientPeak(coefficientMap)
      // 波谷
      val (minPeriod, coefficientTroughList) = coefficientTrough(coefficientMap)

      val min = values.min
      val valueLimit = if (delta < 1) math.min(min + (wvalues.max - wvalues.min) * delta, 0.1f) else delta
      top3NearStable(peak = false, wvalues.max, minPeriod, min, coefficientMap.map(kv => {
        val valueKeys = kv._2._3
        (s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}", (kv._2._1, kv._2._2))
      }), valueKeys, coefficientLimit, condition, valueLimit, minSize)
    }
  }

  def main2(args: Array[String]): Unit = {
    val coefficientLimit = 0.1f
    val condition = "value"
    val delta = 0.2f
    val minSize = 3
    val begin = "20191014"
    val end = "20191027"
    val dataFile = Source.fromFile(s"/home/iss/Downloads/gsta/5gai_spark_2/wid_dwprb_${begin}_$end.csv")
    val dataList = dataFile.getLines().map(_.trim.split(",")).toList
    dataFile.close()

    val schemaFile = Source.fromFile("/home/iss/Downloads/gsta/5gai_spark_2/src/main/resources/sql/WID_DWPRB_DAY.sql")
    val fields = schemaFile.getLines().slice(16, 135).map(_.trim.split("\\s+")).map(columns => columns(0)).toList
    schemaFile.close()

    logger.info(s"`enodebid`|`cellid`|${fields.mkString("|")}|`day`")

    val calendarBegin = Calendar.getInstance()
    calendarBegin.setTime(dateFmt.parse(begin))

    val calendarEnd = Calendar.getInstance()
    calendarEnd.setTime(dateFmt.parse(end))
    calendarEnd.add(Calendar.DATE, 1)

    val valueKeys = 0.to(23)
    dataList.slice(1, dataList.length).foreach(data => {
      val enodebid = data.head
      val cellid = data(1)
      val tweekRealValues = data.slice(2, data.length).map(_.toLowerCase())
      var page = 1
      while (calendarBegin.before(calendarEnd)) {
        val values = tweekRealValues.slice((page - 1) * 24, page * 24)
        val fillValues = mutable.ListBuffer[Float]()
        // 补数
        values.indices.foreach(i => {
          if (values(i) == "null") {
            val j = (page - 1) * 24 + i
            var mean = if (j > 0 && j < tweekRealValues.length - 1 && tweekRealValues(j - 1) != "null" && tweekRealValues(j + 1) != "null") {
              (tweekRealValues(j - 1).toFloat + tweekRealValues(j + 1).toFloat) / 2
            } else {
              -1
            }
            fillValues.append(mean)
          } else {
            fillValues.append(values(i).toFloat)
          }
        })
        if (fillValues.count(_ > -1) > 0) {
          // 静态属性
          val row = mutable.ListBuffer[String](enodebid, cellid)
          // 前两周数据(非填充)
          // 原始数据
          row.appendAll(values)

          val realValues = fillValues.filter(_ > -1)
          val fullFlag = values.count(x => x != "null")
          val fillFullFlag = realValues.length

          fillValues.foreach(x => if (x >= 0) row.append(x.toString) else row.append(""))
          row.append(fullFlag.toString)
          row.append(fillFullFlag.toString)
          row.appendAll(baseCoefficient(fillValues, valueKeys))
          // low1 ~ low8
          row.appendAll(GenerateDay.lowPeriod(fillValues))
          // logger.info(s"[${dateFmt.format(calendarBegin.getTime)}]:[${fillValues.mkString(",")}]")
          val tweekValues = tweekRealValues.filterNot(_ == "null").map(_.toFloat)
          if (realValues.nonEmpty && tweekValues.max != realValues.min) {
            // 切分平稳周期
            /*if (delta < 1) {
              // dwprb
            } else {
              // maxact
              // row.appendAll(GenerateDay.zeroLessActuser(fillValues, valueKeys, coefficientMap.toMap))
            }*/

            if (fillValues.length > realValues.length) {
              1.to(valueKeys.length + 26).foreach(_ => row.append(""))
            } else {
              logger.debug(tweekValues.mkString(","))
              val coefficientMap = splitValuesPro(tweekValues.max, fillValues, valueKeys, minSize)
              row.appendAll(coefficientScore(coefficientMap))
              // 波峰
              val (_, coefficientPeakList) = coefficientPeak(coefficientMap)
              row.appendAll(coefficientPeakList)
              // 波谷
              val (minPeriod, coefficientTroughList) = coefficientTrough(coefficientMap)
              row.appendAll(coefficientTroughList)

              val min = realValues.min
              val valueLimit = if (delta < 1) min + (tweekValues.max - tweekValues.min) * delta else delta
              row.appendAll(top3NearStable(peak = false, tweekValues.max, minPeriod, min, coefficientMap.map(kv => {
                val valueKeys = kv._2._3
                (s"${fmt2Bit(valueKeys.head)}:${fmt2Bit(valueKeys.last)}", (kv._2._1, kv._2._2))
              }), valueKeys, coefficientLimit, condition, valueLimit, minSize))
            }
          } else {
            85.to(134).foreach(_ => row.append("null"))
          }
          row.append(dayOfWeek(calendarBegin).toString)
          row.append(dateFmt.format(calendarBegin.getTime))
          logger.info(row.mkString("|").replaceAll("'", ""))
        }
        calendarBegin.add(Calendar.DATE, 1)
        page = page + 1
      }
      calendarBegin.setTime(dateFmt.parse(begin))
    })
  }
}
